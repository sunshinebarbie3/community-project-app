/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  email: string;
  username: string;
  createdAt: string;
}

export interface Shelter {
  id: string;
  name: string;
  location: string;
  area: string;
  phone: string;
  services: string[];
  capacity: 'Available' | 'Limited' | 'Full';
  coordinates: { lat: number; lng: number };
}

export interface IncidentReport {
  id: string;
  title: string;
  type: string;
  date: string;
  time: string;
  description: string;
  confidentiality: 'High' | 'Strict Vault Only' | 'Share with Advocates';
  attachments: string[]; // Mock file names or base64
  status: 'Received' | 'Assigned Support Specialist' | 'Investigation Active';
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot' | 'system';
  text: string;
  timestamp: string;
}

export interface PersonalContact {
  id: string;
  name: string;
  relationship: string;
  phone: string;
}
