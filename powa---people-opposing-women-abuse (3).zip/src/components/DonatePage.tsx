import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, Shield, Lock, CreditCard, Send, Sparkles, AlertCircle } from 'lucide-react';

export default function DonatePage() {
  const [amount, setAmount] = useState<string>('250');
  const [customAmount, setCustomAmount] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'eft' | 'snapscan'>('card');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  const preSets = ['50', '150', '250', '500', '1000'];

  const getImpactMessage = (val: string) => {
    const num = parseInt(val) || 0;
    if (num <= 0) return "Every contribution helps us sustain our support services.";
    if (num <= 50) return "Feeds a survivor in our safe shelter for one full day.";
    if (num <= 150) return "Provides one dynamic counseling session with a qualified counselor.";
    if (num <= 300) return "Funds transport and intake requirements for an emergency shelter placement.";
    if (num <= 600) return "Supports a legal consultant to assist a survivor with securing a Protection Order.";
    if (num <= 1200) return "Covers a client's intensive therapeutic counseling program for a full month.";
    return "Provides full-spectrum shelter, legal guidance, and counseling support to a survivor and her children.";
  };

  const handleAmountSelect = (val: string) => {
    setAmount(val);
    setCustomAmount('');
  };

  const handleCustomAmountChange = (val: string) => {
    // Only numbers
    const cleanVal = val.replace(/\D/g, '');
    setCustomAmount(cleanVal);
    setAmount(cleanVal);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseInt(amount) <= 0) {
      setErrorMsg('PLEASE SPECIFY AN AMOUNT GREATER THAN R0.');
      return;
    }
    if (!email) {
      setErrorMsg('EMAIL IS REQUIRED UNDER SECURE PROTOCOLS.');
      return;
    }
    setErrorMsg('');
    setIsSubmitted(true);
  };

  const finalAmount = amount || '0';

  if (isSubmitted) {
    return (
      <motion.section 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="py-32 px-12 md:px-24 flex flex-col items-center text-center"
      >
        <div className="w-24 h-24 bg-accent text-white flex items-center justify-center mb-10 border-4 border-dark">
          <Sparkles className="w-12 h-12" />
        </div>
        <h1 className="text-4xl md:text-7xl font-black text-dark mb-6 tracking-tighter uppercase">
          THANK YOU FOR SAFELY SUPPORTING!
        </h1>
        <p className="text-lg font-bold uppercase tracking-[0.1em] text-dark/70 max-w-xl leading-relaxed mb-12">
          Your donation of <span className="text-accent font-black text-2xl">R{finalAmount}</span> protects women and rebuilds lives in South Africa. A secure copy of your Section 18A tax-deductible receipt has been dispatched to <span className="font-extrabold text-dark">{email}</span>.
        </p>
        <div className="bg-white border-4 border-dark p-8 max-w-md w-full mb-12">
          <h3 className="text-xl font-black mb-4 text-left border-b-2 border-dark pb-2">TRANSACTION DETAILS</h3>
          <div className="space-y-4 text-left font-black text-xs uppercase tracking-wider text-dark/60">
            <div className="flex justify-between">
              <span>CONTRIBUTOR:</span>
              <span className="text-dark">{name || 'ANONYMOUS'}</span>
            </div>
            <div className="flex justify-between">
              <span>SUPPORT REF:</span>
              <span className="text-dark">PW-DN-{Math.floor(100000 + Math.random() * 900000)}</span>
            </div>
            <div className="flex justify-between">
              <span>DESTINATION:</span>
              <span className="text-accent font-extrabold">e.sos NATIONAL SHELTERS</span>
            </div>
          </div>
        </div>
        <button 
          onClick={() => {
            setIsSubmitted(false);
            setAmount('250');
            setEmail('');
            setName('');
            setPhone('');
          }}
          className="brutalist-btn-red text-xl py-4 px-12"
        >
          MAKE ANOTHER DONATION
        </button>
      </motion.section>
    );
  }

  return (
    <section className="py-24 px-6 md:px-16 bg-page">
      <div className="max-w-4xl mx-auto">
        
        {/* Page Header */}
        <div className="text-center mb-16">
          <div className="inline-flex w-16 h-16 bg-accent items-center justify-center mb-6 border-4 border-dark">
            <Heart className="w-8 h-8 text-white fill-white" />
          </div>
          <h1 className="text-5xl md:text-8xl font-black text-dark leading-none tracking-tighter uppercase mb-6">
            REBUILD LIVES
          </h1>
          <p className="text-sm font-bold uppercase tracking-widest text-dark/60 max-w-xl mx-auto">
            e.sos is a registered NPO (001-314). All contributions are secure, confidential, and Section 18A tax-deductible.
          </p>
        </div>

        {/* Impact Cards Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="border-4 border-dark bg-white p-6 relative">
            <div className="absolute top-4 right-4 w-3 h-3 bg-accent rounded-full" />
            <h3 className="text-lg font-black mb-2 text-accent">R50</h3>
            <p className="text-xs font-bold uppercase tracking-wide text-dark/70">
              Feeds one survivor in our secure shelter for a full day.
            </p>
          </div>
          <div className="border-4 border-dark bg-white p-6 relative">
            <div className="absolute top-4 right-4 w-3 h-3 bg-accent rounded-full" />
            <h3 className="text-lg font-black mb-2 text-accent">R250</h3>
            <p className="text-xs font-bold uppercase tracking-wide text-dark/70">
              Provides an emergency therapy and intake session for a new survivor.
            </p>
          </div>
          <div className="border-4 border-dark bg-white p-6 relative">
            <div className="absolute top-4 right-4 w-3 h-3 bg-accent rounded-full" />
            <h3 className="text-lg font-black mb-2 text-accent">R1000</h3>
            <p className="text-xs font-bold uppercase tracking-wide text-dark/70">
              Funds complete legal representation and advocacy to secure standard protection orders.
            </p>
          </div>
        </div>

        {/* Dynamic Calculator & Form */}
        <div className="border-4 border-dark bg-white p-8 md:p-12 mb-12">
          <form onSubmit={handleSubmit} className="space-y-8">
            
            {/* Amount Selection */}
            <div className="space-y-4">
              <label className="block text-sm font-black uppercase tracking-widest text-dark/70">
                1. SELECT DONATION AMOUNT (ZAR)
              </label>
              <div className="flex flex-wrap gap-4">
                {preSets.map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => handleAmountSelect(val)}
                    className={`flex-1 min-w-[70px] py-4 border-2 border-dark font-black text-lg transition-colors ${
                      amount === val && !customAmount
                        ? 'bg-accent text-white'
                        : 'bg-page text-dark hover:bg-dark hover:text-white'
                    }`}
                  >
                    R{val}
                  </button>
                ))}
              </div>

              {/* Custom Amount */}
              <div className="relative mt-4">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-xl text-dark">R</span>
                <input
                  type="text"
                  value={customAmount}
                  onChange={(e) => handleCustomAmountChange(e.target.value)}
                  placeholder="ENTER CUSTOM AMOUNT (R)"
                  className="w-full bg-page border-2 border-dark p-4 pl-10 font-black text-lg outline-none focus:bg-accent focus:text-white uppercase placeholder-dark/30 transition-colors"
                />
              </div>

              {/* Impact text indicator */}
              {finalAmount && (
                <div className="bg-accent/5 border-l-4 border-accent p-4 mt-2">
                  <p className="text-xs font-bold uppercase tracking-wider text-dark/40 mb-1">
                    YOUR IMPACT:
                  </p>
                  <p className="text-sm font-black text-accent uppercase tracking-tight">
                    {getImpactMessage(finalAmount)}
                  </p>
                </div>
              )}
            </div>

            {/* Billing details */}
            <div className="space-y-6 pt-6 border-t-2 border-dark/10">
              <label className="block text-sm font-black uppercase tracking-widest text-dark/70">
                2. YOUR SECURE INFO
              </label>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-dark/40">FULL NAME (ANONYMOUS IF BLANK)</span>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="ENTER YOUR FULL NAME"
                    className="w-full bg-page border-2 border-dark p-4 font-black text-xs outline-none focus:border-accent uppercase"
                  />
                </div>
                <div className="space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-dark/40">EMAIL ADDRESS (REQUIRED FOR TAX RECEIPT) *</span>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ENTER EMAIL ADDRESS"
                    className="w-full bg-page border-2 border-dark p-4 font-black text-xs outline-none focus:border-accent uppercase"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-dark/40">PHONE NUMBER (OPTIONAL)</span>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+27 MOBILE NO."
                  className="w-full bg-page border-2 border-dark p-4 font-black text-xs outline-none focus:border-accent"
                />
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-4 pt-6 border-t-2 border-dark/10">
              <label className="block text-sm font-black uppercase tracking-widest text-dark/70">
                3. SECURE INTERACTION PAYMENT MODULE
              </label>
              <div className="grid md:grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`flex items-center gap-3 justify-center p-4 border-2 border-dark font-black text-xs ${
                    paymentMethod === 'card' ? 'bg-dark text-white' : 'bg-page text-dark'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  CREDIT / DEBIT CARD
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('eft')}
                  className={`flex items-center gap-3 justify-center p-4 border-2 border-dark font-black text-xs ${
                    paymentMethod === 'eft' ? 'bg-dark text-white' : 'bg-page text-dark'
                  }`}
                >
                  <Send className="w-4 h-4" />
                  SECURE INSTANT EFT
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('snapscan')}
                  className={`flex items-center gap-3 justify-center p-4 border-2 border-dark font-black text-xs ${
                    paymentMethod === 'snapscan' ? 'bg-dark text-white' : 'bg-page text-dark'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  SNAPSCAN / ZAPPER
                </button>
              </div>

              {/* Secure note */}
              <div className="flex items-center gap-3 text-[10px] font-bold text-dark/40 uppercase tracking-widest pt-2">
                <Lock className="w-3.5 h-3.5 text-accent" />
                END-TO-END AES-256 BIT ENCRYPTION PROTOCOLS APPLIED
              </div>
            </div>

            {errorMsg && (
              <div className="bg-accent text-white p-4 font-black text-xs uppercase tracking-widest flex items-center gap-3">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              className="w-full brutalist-btn-red py-6 text-xl transition-all font-black flex items-center gap-3 justify-center"
            >
              CONFIRM SECURE DONATION OF R{finalAmount}
            </button>
          </form>
        </div>

        {/* Bank details for direct transfer */}
        <div className="border-4 border-dark bg-dark text-white p-8">
          <h4 className="text-xl font-black mb-4 text-[#F9F7F2]">DIRECT BANKING DETAILS (EFT)</h4>
          <p className="text-xs uppercase tracking-widest font-bold text-[#fafafa] opacity-60 leading-relaxed mb-6">
            If you wish to make an immediate, direct bank transfer or set up a monthly debit order, use the absolute coordinates below:
          </p>
          <div className="grid md:grid-cols-2 gap-6 text-xs font-black uppercase tracking-wider text-[#fafafa]/80">
            <div>
              <p className="opacity-40">BANK NAME:</p>
              <p className="text-white text-sm font-extrabold">STANDARD BANK SOUTH AFRICA</p>
            </div>
            <div>
              <p className="opacity-40">ACCOUNT NAME:</p>
              <p className="text-white text-sm font-extrabold">e.sos SUPPORT FUND (POWA)</p>
            </div>
            <div>
              <p className="opacity-40">ACCOUNT NUMBER:</p>
              <p className="text-white text-sm font-extrabold">012 345 6789</p>
            </div>
            <div>
              <p className="opacity-40">BRANCH CODE / REF:</p>
              <p className="text-white text-sm font-extrabold">051 001 (REF: DONATION)</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
