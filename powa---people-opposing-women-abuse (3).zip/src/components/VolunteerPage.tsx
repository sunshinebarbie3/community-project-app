import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Send, Sparkles, CheckCircle, Clock, BookOpen, Scale, MessageSquare, ShieldAlert } from 'lucide-react';

export default function VolunteerPage() {
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [role, setRole] = useState<string>('Crisis Helpline Operator');
  const [availability, setAvailability] = useState<string[]>([]);
  const [motivation, setMotivation] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  const roles = [
    { name: 'Crisis Helpline Operator', desc: 'Direct telephonic support and emergency referrals after intensive e.sos training.', icon: ShieldAlert },
    { name: 'Counseling & Social Support', desc: 'Assist certified social workers during intake and support groups.', icon: MessageSquare },
    { name: 'Community Awareness & Events', desc: 'Coordinating workshops, distributions, and local activism drives.', icon: BookOpen },
    { name: 'Legal Aid Helper', desc: 'Helping survivors fill in protection order paperworks and coordinate appointments.', icon: Scale },
  ];

  const toggleAvailability = (day: string) => {
    if (availability.includes(day)) {
      setAvailability(availability.filter(d => d !== day));
    } else {
      setAvailability([...availability, day]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) {
      setErrorMsg('FULL NAME IS MANDATORY FOR SCREENING AUDITS.');
      return;
    }
    if (!email) {
      setErrorMsg('VALID DECRYPTION EMAIL SPECIFICATION IS OBLIGATORY.');
      return;
    }
    if (!motivation || motivation.length < 20) {
      setErrorMsg('PLEASE EXPAND ON YOUR MOTIVATION. MINIMUM 20 CHARACTERS.');
      return;
    }
    if (availability.length === 0) {
      setErrorMsg('AT LEAST ONE AVAILABILITY SELECTION IS MANDATORY.');
      return;
    }
    setErrorMsg('');
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <motion.section 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="py-32 px-12 md:px-24 flex flex-col items-center text-center bg-page"
      >
        <div className="w-24 h-24 bg-accent text-white flex items-center justify-center mb-10 border-4 border-dark">
          <Sparkles className="w-12 h-12" />
        </div>
        <h1 className="text-4xl md:text-7xl font-black text-dark mb-6 tracking-tighter uppercase">
          YOU ARE PART OF THE SOLUTION!
        </h1>
        <p className="text-lg font-bold uppercase tracking-[0.1em] text-dark/70 max-w-xl leading-relaxed mb-12">
          Thank you, <span className="text-accent font-black">{name}</span>. Your application for <span className="font-extrabold text-dark">{role}</span> has been processed securely. A screening officer will reach out to you via <span className="font-extrabold text-dark">{email}</span> within 48 to 72 hours for scheduling your first briefing.
        </p>

        <div className="bg-white border-4 border-dark p-8 max-w-md w-full mb-12">
          <h3 className="text-xl font-black mb-4 text-left border-b-2 border-dark pb-3 uppercase">APPLICATION CARD</h3>
          <div className="space-y-4 text-left font-black text-xs uppercase tracking-wider text-dark/60">
            <div className="flex justify-between">
              <span>APPLICANT:</span>
              <span className="text-dark">{name}</span>
            </div>
            <div className="flex justify-between">
              <span>DESIGNATION:</span>
              <span className="text-accent font-extrabold">{role}</span>
            </div>
            <div className="flex justify-between">
              <span>TIMEFRAME:</span>
              <span className="text-dark">{availability.join(', ')}</span>
            </div>
          </div>
        </div>

        <button 
          onClick={() => {
            setIsSubmitted(false);
            setName('');
            setPhone('');
            setEmail('');
            setMotivation('');
            setAvailability([]);
          }}
          className="brutalist-btn-red text-xl py-4 px-12"
        >
          SUBMIT ANOTHER APPLICATION
        </button>
      </motion.section>
    );
  }

  return (
    <section className="py-24 px-6 md:px-16 bg-page">
      <div className="max-w-4xl mx-auto">
        
        {/* Page Header */}
        <div className="text-center mb-16">
          <div className="inline-flex w-16 h-16 bg-accent items-center justify-center mb-6 border-4 border-dark">
            <CheckCircle className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-5xl md:text-8xl font-black text-dark leading-none tracking-tighter uppercase mb-6">
            JOIN THE MOVEMENT
          </h1>
          <p className="text-sm font-bold uppercase tracking-widest text-dark/60 max-w-xl mx-auto">
            Become a core volunteer at e.sos. Provide support, lead campaigns, assist with administration, and directly rebuild lives.
          </p>
        </div>

        {/* Roles Details */}
        <div className="space-y-6 mb-16">
          <h2 className="text-2xl font-black uppercase text-dark tracking-tighter">
            AVAILABLE OPPORTUNITIES
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {roles.map((r, i) => {
              const Icon = r.icon;
              return (
                <div key={i} className="border-4 border-dark bg-white p-8 flex flex-col justify-between">
                  <div>
                    <div className="w-12 h-12 bg-page border-2 border-dark flex items-center justify-center mb-6 text-accent">
                      <Icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-black uppercase mb-3">{r.name}</h3>
                    <p className="text-xs uppercase tracking-wide font-bold text-dark/60 leading-relaxed">
                      {r.desc}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setRole(r.name);
                      document.getElementById('vol-form')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="mt-6 border-2 border-dark bg-page py-2 font-black text-xs hover:bg-dark hover:text-white transition-colors"
                  >
                    SELECT THIS SERVICE
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Application Form */}
        <div id="vol-form" className="border-4 border-dark bg-white p-8 md:p-12">
          <h2 className="text-2xl font-black uppercase text-dark tracking-tighter mb-8 border-b-4 border-dark pb-4 flex items-center gap-3">
            <Clock className="w-6 h-6 text-accent" />
            VOLUNTEER SIGN-UP PORTAL
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-8">
            
            {/* Department Selector */}
            <div className="space-y-2">
              <label className="block text-xs font-black uppercase tracking-widest text-dark/60">
                1. PREFERRED VOLUNTEER DEPARTMENT / ROLE *
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full bg-page border-2 border-dark p-4 font-black uppercase outline-none focus:bg-accent focus:text-white transition-colors cursor-pointer"
              >
                {roles.map((r) => (
                  <option key={r.name} value={r.name}>{r.name.toUpperCase()}</option>
                ))}
                <option value="General Admin Support">GENERAL ADMIN & CLERICAL SUPPORT</option>
                <option value="Media & Marketing Volunteer">MEDIA, DESIGN & MARKETING HELP</option>
              </select>
            </div>

            {/* Applicant Personal details */}
            <div className="space-y-6">
              <label className="block text-xs font-black uppercase tracking-widest text-dark/60">
                2. YOUR SECURE PROTOCOL CONTACT INFO
              </label>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-dark/40">FULL NAME *</span>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="ENTER FULL NAME"
                    className="w-full bg-page border-2 border-dark p-4 font-black text-xs outline-none focus:border-accent uppercase"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-dark/40">EMAIL ADDRESS *</span>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ENTER SECURE EMAIL"
                    className="w-full bg-page border-2 border-dark p-4 font-black text-xs outline-none focus:border-accent uppercase"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-dark/40">CELULAR / MOBILE NO. (OPTIONAL)</span>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+27 MOBILE NO."
                  className="w-full bg-page border-2 border-dark p-4 font-black text-xs outline-none focus:border-accent"
                />
              </div>
            </div>

            {/* Availability */}
            <div className="space-y-4">
              <label className="block text-xs font-black uppercase tracking-widest text-dark/60">
                3. SPECIFY AVAILABILITY CO-ORDINATES *
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {['WEEKDAYS', 'WEEKENDS', 'MORNINGS', 'AFTERNOONS'].map((day) => {
                  const isSel = availability.includes(day);
                  return (
                    <button
                      key={day}
                      type="button"
                      onClick={() => toggleAvailability(day)}
                      className={`py-3 border-2 border-dark font-black text-xs transition-colors ${
                        isSel ? 'bg-accent text-white' : 'bg-page text-dark hover:bg-dark hover:text-white'
                      }`}
                    >
                      {day}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Motivation statement */}
            <div className="space-y-2">
              <label className="block text-xs font-black uppercase tracking-widest text-dark/60">
                4. MOTIVATION STATEMENT *
              </label>
              <textarea
                rows={4}
                value={motivation}
                onChange={(e) => setMotivation(e.target.value)}
                placeholder="PLEASE EXPLAIN IN A FEW SENTENCES WHY YOU WANT TO VOLUNTEER FOR E.SOS..."
                className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs outline-none resize-none focus:border-accent"
                required
              />
            </div>

            {errorMsg && (
              <div className="bg-accent text-white p-4 font-black text-xs uppercase tracking-widest">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              className="w-full brutalist-btn-red py-6 text-xl transition-all font-black flex items-center gap-3 justify-center"
            >
              <Send className="w-5 h-5" />
              SUBMIT VOLUNTEER APPLICATION
            </button>
          </form>
        </div>

      </div>
    </section>
  );
}
