/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, MapPin, Phone, ShieldCheck, Check, Info, Heart, ArrowUpRight, Bus } from 'lucide-react';
import { Shelter } from '../types';

// High-quality details for shelters across South Africa
const SHELTER_DATA: Shelter[] = [
  {
    id: 's1',
    name: 'Frida Hartley Shelter',
    location: 'Yeoville, Johannesburg',
    area: 'Gauteng',
    phone: '011 648 6005',
    services: ['Counseling', 'Skills Development', 'Employment Support', 'Children Welcome'],
    capacity: 'Available',
    coordinates: { lat: 25, lng: 32 }
  },
  {
    id: 's2',
    name: 'Nisaa Institute for Women\'s Development',
    location: 'Lenasia, Johannesburg',
    area: 'Gauteng',
    phone: '011 854 6372',
    services: ['Legal Advocacy', 'Clinical Therapy', 'Immediate Admission', 'Children Welcome'],
    capacity: 'Limited',
    coordinates: { lat: 30, lng: 45 }
  },
  {
    id: 's3',
    name: 'POWA Crisis Safe House',
    location: 'Berea, Johannesburg',
    area: 'Gauteng',
    phone: '011 642 4345',
    services: ['24/7 Security', 'Psychosocial Support', 'Legal Aid', 'Emergency Transport'],
    capacity: 'Available',
    coordinates: { lat: 40, lng: 55 }
  },
  {
    id: 's4',
    name: 'Sisters Incorporated',
    location: 'Kenilworth, Cape Town',
    area: 'Western Cape',
    phone: '021 797 4190',
    services: ['Pregnancy Support', 'Infant Care', 'Individual Therapy', 'Long-term Stay'],
    capacity: 'Limited',
    coordinates: { lat: 60, lng: 20 }
  },
  {
    id: 's5',
    name: 'Saartjie Baartman Centre',
    location: 'Manenberg, Cape Town',
    area: 'Western Cape',
    phone: '021 633 5287',
    services: ['Child Counseling', 'Legal Advice Clinic', 'Residential Shelter', 'Medical Care'],
    capacity: 'Full',
    coordinates: { lat: 70, lng: 15 }
  },
  {
    id: 's6',
    name: 'The Safe House',
    location: 'Stellenbosch',
    area: 'Western Cape',
    phone: '0861 322 322',
    services: ['Security Guards', 'Trauma Counseling', 'Safe Haven'],
    capacity: 'Available',
    coordinates: { lat: 65, lng: 28 }
  },
  {
    id: 's7',
    name: 'Open Door Crisis Care Centre',
    location: 'Pinetown, Durban',
    area: 'KwaZulu-Natal',
    phone: '031 709 2637',
    services: ['Trauma Center', 'Social Work Services', 'Support Groups', 'Court Accompaniment'],
    capacity: 'Available',
    coordinates: { lat: 10, lng: 80 }
  }
];

export default function FindShelterPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArea, setSelectedArea] = useState<string>('ALL');
  const [selectedService, setSelectedService] = useState<string>('ALL');
  const [bookingStatus, setBookingStatus] = useState<{ [key: string]: string }>({});
  const [showMapRoute, setShowMapRoute] = useState<string | null>(null);

  const areas = ['ALL', ...Array.from(new Set(SHELTER_DATA.map(s => s.area)))];
  
  const allServices = Array.from(
    new Set(SHELTER_DATA.flatMap(s => s.services))
  ).sort();

  const filteredShelters = SHELTER_DATA.filter(shelter => {
    const matchesSearch = shelter.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          shelter.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesArea = selectedArea === 'ALL' || shelter.area === selectedArea;
    const matchesService = selectedService === 'ALL' || shelter.services.includes(selectedService);
    return matchesSearch && matchesArea && matchesService;
  });

  const handleBookEmergency = (shelterId: string) => {
    setBookingStatus(prev => ({ ...prev, [shelterId]: 'PENDING' }));
    
    setTimeout(() => {
      setBookingStatus(prev => ({
        ...prev,
        [shelterId]: 'SUCCESS'
      }));
    }, 1500);
  };

  return (
    <div className="py-24 px-6 max-w-5xl mx-auto space-y-12">
      {/* Page Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-7xl font-black text-dark tracking-tighter">
          FIND SAFE <span className="text-accent underline decoration-8">SHELTER</span>
        </h1>
        <p className="text-sm font-bold uppercase tracking-widest text-dark/60 max-w-xl mx-auto px-4">
          NATIONWIDE DISCREET PARTNER SAFE-HOUSES AND ASSISTED CRISIS HOMES. ACTIVE CAPACITY LOGS SYNCED RECENTLY.
        </p>
      </div>

      {/* Control Panel: Filters & Search */}
      <div className="bg-white border-4 border-dark p-8 md:p-10 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-8">
        <div className="grid md:grid-cols-12 gap-6 items-center">
          {/* Search Input */}
          <div className="md:col-span-6 relative">
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="SEARCH BY CITY, NAME OR SUBURB..."
              className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs pl-12 focus:bg-accent focus:text-white transition-colors outline-none"
            />
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 opacity-40" />
          </div>

          {/* Area Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedArea}
              onChange={(e) => setSelectedArea(e.target.value)}
              className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs outline-none cursor-pointer"
            >
              <option value="ALL">ALL PROVINCES</option>
              {areas.filter(a => a !== 'ALL').map(area => (
                <option key={area} value={area}>{area}</option>
              ))}
            </select>
          </div>

          {/* Service Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs outline-none cursor-pointer"
            >
              <option value="ALL">ALL SERVICES</option>
              {allServices.map(service => (
                <option key={service} value={service}>{service}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Security Warning Panel */}
        <div className="bg-dark text-white p-4 flex gap-3 items-center border-l-4 border-accent">
          <ShieldCheck className="w-6 h-6 text-accent shrink-0 animate-pulse" />
          <p className="text-[10px] font-black uppercase tracking-widest leading-relaxed">
            GPS SHIELDS ACTIVE: FOR SECURITY AND DISCRETION, EXACT PRIMARY LOCATION COORDINATES OF WOMEN-ABUSE SHELTERS ARE DE-INDEXED. COORDINATED EMERGENCY TRANSPORT STATIONS WILL BE SCHEDULED FOR YOU.
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-12 items-start">
        {/* Active Shelters List */}
        <div className="lg:col-span-7 space-y-8">
          {filteredShelters.length === 0 ? (
            <div className="border-4 border-dotted border-dark p-12 text-center text-dark/50">
              <p className="text-xl font-black uppercase mb-2">NO COMPLIANT SHELTERS FOUND</p>
              <p className="text-xs font-bold uppercase tracking-widest">TRY EXPANDING YOUR AREA OR PROVINCIAL SEARCH FILTER</p>
            </div>
          ) : (
            filteredShelters.map((shelter) => (
              <motion.div
                layout
                key={shelter.id}
                className="bg-white border-4 border-dark p-6 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] hover:shadow-none hover:translate-x-[2px] hover:translate-y-[2px] transition-all"
              >
                <div className="flex justify-between items-start gap-4 flex-wrap pb-4 border-b-2 border-dark/10">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black uppercase tracking-widest text-[#E63946]">{shelter.area}</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-dark/20" />
                      <span className="text-[10px] font-extrabold uppercase tracking-widest bg-dark/5 px-2 py-0.5 text-dark/70">{shelter.location}</span>
                    </div>
                    <h3 className="text-xl md:text-2xl font-black uppercase">{shelter.name}</h3>
                  </div>

                  <span className={`px-4 py-1.5 text-xs font-black uppercase border-2 border-dark ${
                    shelter.capacity === 'Available' ? 'bg-green-100 text-green-800' :
                    shelter.capacity === 'Limited' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {shelter.capacity} CAPACITY
                  </span>
                </div>

                <div className="py-4 space-y-4">
                  <p className="text-[10px] font-black uppercase tracking-widest text-dark/40">AVAILABLE SERVICES</p>
                  <div className="flex flex-wrap gap-2">
                    {shelter.services.map((srv, idx) => (
                      <span key={idx} className="bg-page border-2 border-dark px-3 py-1 text-[10px] font-black uppercase flex items-center gap-1">
                        <Check className="w-3 h-3 text-accent" />
                        {srv}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t-2 border-dashed border-dark/10 flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4">
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-dark" />
                    <a href={`tel:${shelter.phone}`} className="text-sm font-black text-dark hover:underline uppercase">
                      CALL SHELTER: {shelter.phone}
                    </a>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowMapRoute(showMapRoute === shelter.id ? null : shelter.id)}
                      className="brutalist-btn-outline text-xs px-4 py-3 bg-page text-dark shrink-0 flex items-center gap-1.5"
                    >
                      <MapPin className="w-4 h-4 text-accent" />
                      {showMapRoute === shelter.id ? 'CLOSE MAP' : 'ROUTE STATION'}
                    </button>
                    
                    <button
                      onClick={() => handleBookEmergency(shelter.id)}
                      disabled={bookingStatus[shelter.id] === 'SUCCESS' || shelter.capacity === 'Full'}
                      className={`brutalist-btn-red text-xs px-6 py-3 shrink-0 ${
                        bookingStatus[shelter.id] === 'SUCCESS' ? 'bg-green-600 text-white' : ''
                      }`}
                    >
                      {bookingStatus[shelter.id] === 'PENDING' ? 'SECURING...' :
                       bookingStatus[shelter.id] === 'SUCCESS' ? 'STATION LOCKED!' :
                       shelter.capacity === 'Full' ? 'FULL HOUSE' : 'REQUEST EN-ROUTE STATION'}
                    </button>
                  </div>
                </div>

                {/* Simulated route Map representation inside the card grid */}
                {showMapRoute === shelter.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    className="mt-6 border-4 border-dark bg-yellow-50 p-6 overflow-hidden space-y-4"
                  >
                    <div className="flex justify-between items-center bg-dark text-white px-3 py-1.5 text-[9px] font-black uppercase">
                      <span>SECURE TRANSIT COORDINATES</span>
                      <span className="text-light text-accent">GPS ROUTE ACTIVE</span>
                    </div>
                    {/* Retro SVB Brutalist Styled Map Route */}
                    <div className="relative h-44 bg-page border-2 border-dark flex items-center justify-center overflow-hidden">
                      {/* Grid Lines mockup */}
                      <div className="absolute inset-0 grid grid-cols-6 grid-rows-4 gap-4 opacity-5 pointer-events-none">
                        {Array.from({ length: 24 }).map((_, i) => (
                          <div key={i} className="border border-dark" />
                        ))}
                      </div>

                      {/* Path route rendering */}
                      <svg className="absolute w-full h-full p-8" viewBox="0 0 400 200">
                        <line x1="40" y1="140" x2="160" y2="60" stroke="#1A1A1A" strokeWidth="4" strokeDasharray="6,6" />
                        <line x1="160" y1="60" x2="340" y2="100" stroke="#E63946" strokeWidth="6" />
                        
                        {/* Start point */}
                        <circle cx="40" cy="140" r="10" fill="#1A1A1A" />
                        <text x="40" y="125" textAnchor="middle" className="text-[10px] font-black uppercase text-dark fill-current">YOU (SAFE ENCLAVE)</text>
                        
                        {/* Safe Transport Rendezvous point */}
                        <circle cx="160" cy="60" r="10" fill="#60A5FA" />
                        <text x="160" y="45" textAnchor="middle" className="text-[10px] font-black uppercase text-blue-800 fill-current">STATION RENDEZVOUS</text>

                        {/* Destination */}
                        <circle cx="340" cy="100" r="12" fill="#E63946" />
                        <text x="340" y="85" textAnchor="middle" className="text-[10px] font-black uppercase text-accent font-black fill-current">SECURE SHELTER</text>
                      </svg>
                      
                      <div className="absolute bottom-3 left-3 bg-white border border-dark p-2 text-[8px] font-black uppercase flex items-center gap-2">
                        <Bus className="w-3 h-3 text-blue-500" />
                        <span>SAPS ESCORT & COORDINATES SENT TO VOLUNTEER DISPATCHERS</span>
                      </div>
                    </div>
                    
                    <p className="text-[10px] font-black text-dark/60 uppercase">
                      ⚠️ SECURITY NOTE: DO NOT ATTEMPT TO GO DIRECTLY. A REGISTERED e.sos DRIVER OR SOCIAL WORKER WILL MEET YOU AT THE "STATION RENDEZVOUS" TO VERIFY YOUR EMBARKATION FOR ABSOLUTE survivor SECURITY.
                    </p>
                  </motion.div>
                )}
              </motion.div>
            ))
          )}
        </div>

        {/* Right Help Desk Panel */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border-4 border-dark p-8 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-6">
            <h3 className="text-2xl font-black">IMMEDIATE STEPS</h3>
            
            <ol className="space-y-4 list-decimal list-inside text-xs font-black uppercase tracking-wide">
              <li className="p-3 bg-page border-2 border-dark">
                LAUNCH THE <span className="text-accent underline">PANIC BUTTON</span> IF IN IMMEDIATE HARMS WAY.
              </li>
              <li className="p-3 bg-page border-2 border-dark">
                ADD A trusted ALLY CONTACT IN THE PHONEBOOK TO LOG YOUR JOURNEY.
              </li>
              <li className="p-3 bg-page border-2 border-dark">
                USE THE SECURE CHAT TO RECEIVE PRIVATE STEP-BY-STEP ADVICE.
              </li>
              <li className="p-3 bg-page border-2 border-dark font-normal scale-95 opacity-80 decoration-slice">
                USE THE QUICK ESCAPE BUTTON ON SUB-PAGES AT ANY TIME TO INSTANTLY COVER YOUR BROWSING PATH.
              </li>
            </ol>

            <div className="border-t-4 border-dark pt-6 text-[10px] font-black uppercase tracking-wider space-y-2 opacity-70">
              <p>📍 LOCAL CODES VERIFIED</p>
              <p>🤝 PRIVATE ADVOCACY COALITION (POWA)</p>
              <p>🛡️ MILITARY GRADE CLIENT-SIDE DISCRETION</p>
            </div>
          </div>

          <div className="bg-accent text-white border-4 border-dark p-8 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] relative overflow-hidden">
            <h4 className="text-2xl font-black tracking-tight mb-4">NEED SECURE ESCORT?</h4>
            <p className="text-xs font-bold uppercase tracking-widest leading-relaxed opacity-90 mb-6">
              IF YOU REQUIRE DIRECT ASSISTED FLEEING FROM AN ACTIVE DOMESTIC THREAT, OUR GROUND NETWORK OF TAXIS AND FEMALE SECURITY AGENTS CAN REACH YOU DISCREETLY.
            </p>
            <a href="tel:0800428428" className="inline-block bg-white text-dark font-black px-6 py-4 uppercase text-xs border-2 border-dark select-none tracking-widest hover:bg-dark hover:text-white transition-all">
              DISPATCH TRANSPORT: 0800 428 428
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
