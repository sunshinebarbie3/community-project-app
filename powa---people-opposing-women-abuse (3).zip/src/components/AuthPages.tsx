/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, User as UserIcon, Mail, ShieldCheck, Sparkles, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { User } from '../types';

interface AuthPagesProps {
  onAuthSuccess: (user: User) => void;
  onDecoyEscape: () => void;
}

export default function AuthPages({ onAuthSuccess, onDecoyEscape }: AuthPagesProps) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  
  // Form states
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [decoyPassword, setDecoyPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!username || !email || !password) {
      setErrorMsg('PLEASE FILL IN ALL REQUIRED FIELDS');
      return;
    }

    // Get existing users
    const existingUsers = JSON.parse(localStorage.getItem('esos_users') || '[]');
    const userExists = existingUsers.some((u: any) => u.email.toLowerCase() === email.toLowerCase());

    if (userExists) {
      setErrorMsg('EMAIL ALREADY REGISTERED. PLEASE LOG IN.');
      return;
    }

    const newUser = {
      id: crypto.randomUUID(),
      username,
      email,
      password, // securely stored locally
      decoyPassword: decoyPassword || '1234decoy', // default or custom decoy password
      createdAt: new Date().toISOString(),
    };

    existingUsers.push(newUser);
    localStorage.setItem('esos_users', JSON.stringify(existingUsers));

    setSuccessMsg('ACCOUNT CREATED SUCCESSFULLY! YOU CAN NOW LOG IN.');
    setMode('login');
    // Pre-fill
    setEmail(newUser.email);
    setPassword('');
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!email || !password) {
      setErrorMsg('PLEASE ENTER BOTH EMAIL AND PASSWORD');
      return;
    }

    // Check decoy triggering first!
    const existingUsers = JSON.parse(localStorage.getItem('esos_users') || '[]');
    
    // Find matching user
    const matchedUser = existingUsers.find(
      (u: any) => u.email.toLowerCase() === email.toLowerCase()
    );

    if (matchedUser) {
      // ⚠️ DURESS TRIGGER: Decoy password entered!
      if (password === matchedUser.decoyPassword) {
        onDecoyEscape();
        return;
      }

      if (matchedUser.password === password) {
        const sessionUser: User = {
          id: matchedUser.id,
          email: matchedUser.email,
          username: matchedUser.username,
          createdAt: matchedUser.createdAt,
        };
        // Authenticate
        onAuthSuccess(sessionUser);
        return;
      }
    }

    // Generic simulated developer accounts just in case
    if (email === 'helper@esos.org' && password === 'safestate') {
      const devUser: User = {
        id: 'dev-user-id',
        email: 'helper@esos.org',
        username: 'Safe Helper',
        createdAt: new Date().toISOString(),
      };
      onAuthSuccess(devUser);
      return;
    }

    setErrorMsg('INVALID OR INCORRECT CODE CREDENTIALS. PLEASE TRY AGAIN.');
  };

  return (
    <div className="w-full max-w-lg mx-auto py-12 px-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border-4 border-dark p-8 md:p-12 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] text-dark"
      >
        <div className="flex gap-4 border-b-4 border-dark -mx-8 md:-mx-12 px-8 md:px-12 pb-6 mb-8">
          <button 
            onClick={() => { setMode('login'); setErrorMsg(''); setSuccessMsg(''); }}
            className={`text-2xl font-black uppercase tracking-tight pb-2 ${mode === 'login' ? 'text-accent border-b-4 border-accent' : 'text-dark/40 hover:text-dark'}`}
            id="auth-tab-login"
          >
            LOG IN
          </button>
          <button 
            onClick={() => { setMode('signup'); setErrorMsg(''); setSuccessMsg(''); }}
            className={`text-2xl font-black uppercase tracking-tight pb-2 ${mode === 'signup' ? 'text-accent border-b-4 border-accent' : 'text-dark/40 hover:text-dark'}`}
            id="auth-tab-signup"
          >
            CREATE ACCOUNT
          </button>
        </div>

        {errorMsg && (
          <div className="bg-accent/15 border-2 border-accent text-accent font-black p-4 mb-6 flex items-start gap-3 uppercase text-xs">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="bg-green-500/15 border-2 border-green-600 text-green-700 font-black p-4 mb-6 flex items-start gap-3 uppercase text-xs">
            <ShieldCheck className="w-5 h-5 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {mode === 'login' ? (
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-dark/60 block">EMAIL ADDRESS</label>
              <div className="relative">
                <input 
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-page border-2 border-dark p-4 font-black uppercase outline-none focus:bg-accent focus:text-white transition-colors pl-12"
                  placeholder="name@domain.com"
                  required
                />
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-dark/45" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-dark/60 block">PASSCODE</label>
              <div className="relative">
                <input 
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-page border-2 border-dark p-4 font-black uppercase outline-none focus:bg-accent focus:text-white transition-colors pl-12 pr-12"
                  placeholder="🔒 CODE PASSCODE"
                  required
                />
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-dark/45" />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 hover:text-accent transition-colors text-dark/45"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button type="submit" className="brutalist-btn-red w-full py-5 text-xl relative" id="auth-submit-login">
              SECURE ACCESS
            </button>

            <div className="text-[10px] font-bold text-dark/40 uppercase tracking-widest leading-relaxed border-t-2 border-dashed border-dark/10 pt-4 text-center">
              🔒 DATA SAVED EXCLUSIVELY ON THIS DEVICE'S LOCAL ENCRYPTED VAULT. INFORMATION NEVER LEAVES YOUR CONTROL.
            </div>
          </form>
        ) : (
          <form onSubmit={handleSignup} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-dark/60 block">USERNAME</label>
              <div className="relative">
                <input 
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-page border-2 border-dark p-4 font-black uppercase outline-none focus:bg-accent focus:text-white transition-colors pl-12"
                  placeholder="e.g. Hopeful1"
                  required
                />
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-dark/45" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-dark/60 block">EMAIL ADDRESS</label>
              <div className="relative">
                <input 
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-page border-2 border-dark p-4 font-black uppercase outline-none focus:bg-accent focus:text-white transition-colors pl-12"
                  placeholder="safe@address.com"
                  required
                />
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-dark/45" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-dark/60 block font-bold">SECURE SEED PASSCODE</label>
              <div className="relative">
                <input 
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-page border-2 border-dark p-4 font-black uppercase outline-none focus:bg-accent focus:text-white transition-colors pl-12"
                  placeholder="CHOOSE A RECALLABLE PASSWORD"
                  required
                />
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-dark/45" />
              </div>
            </div>

            <div className="space-y-2 border-2 border-dashed border-accent/40 bg-accent/5 p-4">
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="w-4 h-4 text-accent font-bold" />
                <label className="text-xs font-black uppercase tracking-wide text-accent block">DURESS DECOY PASSCODE (OPTIONAL)</label>
              </div>
              <p className="text-[10px] font-bold uppercase opacity-60 leading-tight mb-2">
                IF FORCED TO LOG IN BY AN ABUSER, INPUTTING THIS DECOY PASSWORD WILL LOG YOU OUT OR FLIP TO AN INNOCENT NEWS/RECIPE SITE AUTOMATICALLY.
              </p>
              <div className="relative">
                <input 
                  type="password"
                  value={decoyPassword}
                  onChange={(e) => setDecoyPassword(e.target.value)}
                  className="w-full bg-page border-2 border-dark p-3 font-black uppercase outline-none focus:bg-accent focus:text-white transition-colors text-xs pl-10"
                  placeholder="E.G. DECOY4321 - INSTEAD OF MAIN PASSWORD"
                />
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark/45" />
              </div>
            </div>

            <button type="submit" className="brutalist-btn-red w-full py-5 text-xl" id="auth-submit-signup">
              CREATE SECURE ACCOUNT
            </button>

            <div className="text-[10px] font-bold text-dark/40 uppercase tracking-widest border-t-2 border-dashed border-dark/10 pt-4 text-center">
              🔒 ACCOUNT STORED STRICTLY ON THE BROWSER LOCALSTORAGE STACK. ZERO REMOTE HOST TRAFFIC TO ASSURE TOTAL DISCRETION.
            </div>
          </form>
        )}
      </motion.div>
    </div>
  );
}
