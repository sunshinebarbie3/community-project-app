/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Trash2, ShieldAlert, Sparkles, LogIn, Lock, CheckCircle, FileText, Download, Calendar, UploadCloud } from 'lucide-react';
import { IncidentReport, User } from '../types';

interface ReportIncidentPageProps {
  currentUser: User | null;
  onNavigateToAuth: () => void;
}

export default function ReportIncidentPage({ currentUser, onNavigateToAuth }: ReportIncidentPageProps) {
  const [reports, setReports] = useState<IncidentReport[]>([]);
  const [title, setTitle] = useState('');
  const [type, setType] = useState('PHYSICAL ABUSE');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('12:00');
  const [description, setDescription] = useState('');
  const [confidentiality, setConfidentiality] = useState<IncidentReport['confidentiality']>('Strict Vault Only');
  const [dragActive, setDragActive] = useState(false);
  const [attachments, setAttachments] = useState<string[]>([]);
  const [isSubmitSuccess, setIsSubmitSuccess] = useState(false);

  // Load user specific reports
  useEffect(() => {
    if (currentUser) {
      const stored = localStorage.getItem(`esos_reports_${currentUser.id}`);
      if (stored) {
        setReports(JSON.parse(stored));
      } else {
        // Mock starter report for simulation representation
        const initialMock: IncidentReport[] = [
          {
            id: 'rep-mock1',
            title: 'Unlawful tracking & harassments',
            type: 'PSYCHOLOGICAL',
            date: '2026-06-01',
            time: '21:15',
            description: 'Incident of heavy digital tracking and constant calls threatening access lockouts near my home.',
            confidentiality: 'Strict Vault Only',
            attachments: ['screenshot_evidence_01.png'],
            status: 'Received'
          }
        ];
        setReports(initialMock);
        localStorage.setItem(`esos_reports_${currentUser.id}`, JSON.stringify(initialMock));
      }
    }
  }, [currentUser]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const names = Array.from(e.dataTransfer.files).map((f: File) => f.name);
      setAttachments(prev => [...prev, ...names]);
    }
  };

  const handleManualUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const names = Array.from(e.target.files).map((f: File) => f.name);
      setAttachments(prev => [...prev, ...names]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description) return;

    const newReport: IncidentReport = {
      id: `rep-${crypto.randomUUID()}`,
      title,
      type,
      date,
      time,
      description,
      confidentiality,
      attachments,
      status: 'Received'
    };

    const updated = [newReport, ...reports];
    setReports(updated);

    if (currentUser) {
      localStorage.setItem(`esos_reports_${currentUser.id}`, JSON.stringify(updated));
    } else {
      // In guest state, store the report transiently or in a guest local storage
      const guestReports = JSON.parse(localStorage.getItem('esos_guest_reports') || '[]');
      const newGuestReports = [newReport, ...guestReports];
      localStorage.setItem('esos_guest_reports', JSON.stringify(newGuestReports));
    }

    // Set success indicator
    setIsSubmitSuccess(true);
    
    // Reset form fields
    setTitle('');
    setDescription('');
    setAttachments([]);

    setTimeout(() => {
      setIsSubmitSuccess(false);
    }, 5000);
  };

  const handleDeleteReport = (id: string) => {
    const updated = reports.filter(r => r.id !== id);
    setReports(updated);
    if (currentUser) {
      localStorage.setItem(`esos_reports_${currentUser.id}`, JSON.stringify(updated));
    }
  };

  return (
    <div className="py-24 px-6 max-w-5xl mx-auto space-y-12">
      {/* Tab/Page Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-7xl font-black text-dark tracking-tighter">
          SECURE EVIDENCE <span className="text-accent underline decoration-8">VAULT</span>
        </h1>
        <p className="text-sm font-bold uppercase tracking-widest text-dark/60 max-w-xl mx-auto px-4">
          LOG GBV INCIDENTS SECURELY WITH DIGITAL PROOFS. DESIGNED TO TIMELINE HARASSMENTS LEGALLY FOR REQUISITING PROTECTION ORDERS.
        </p>
      </div>

      <div className="grid lg:grid-cols-12 gap-12 items-start">
        {/* Left Side: Submit Incident Form */}
        <div className="lg:col-span-6 space-y-8">
          <div className="bg-white border-4 border-dark p-8 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)]">
            <h2 className="text-2xl font-black mb-6 uppercase border-b-2 border-dark/10 pb-4 flex items-center gap-3">
              <ShieldAlert className="w-6 h-6 text-accent" />
              LOG NEW INCIDENT
            </h2>

            {isSubmitSuccess && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-green-100 border-2 border-green-600 text-green-800 p-4 mb-6 font-black uppercase text-xs flex items-center gap-2"
              >
                <CheckCircle className="w-5 h-5 text-green-700 shrink-0" />
                <span>INCIDENT LOGGED AND SECURED IN YOUR EVIDENCE VAULT METASTACK!</span>
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-dark/60">INCIDENT OVERVIEW TITLE</label>
                <input 
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="E.G., PHONE INTERCEPTIONS OR DOOR STALKING"
                  className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs outline-none focus:bg-accent focus:text-white transition-colors"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-black uppercase tracking-widest text-dark/60">DATE OF THREAT</label>
                  <input 
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-page border-2 border-dark p-4 font-black text-xs outline-none focus:bg-accent focus:text-white transition-colors"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black uppercase tracking-widest text-dark/60">TIME (APPROX)</label>
                  <input 
                    type="time"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full bg-page border-2 border-dark p-4 font-black text-xs outline-none focus:bg-accent focus:text-white transition-colors"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-dark/60">ABUSE & HARASSMENT TYPE</label>
                <select 
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs outline-none"
                >
                  <option value="PHYSICAL ABUSE">PHYSICAL COMPULSION / ASSAULT</option>
                  <option value="PSYCHOLOGICAL">PSYCHOLOGICAL COERCION</option>
                  <option value="ECONOMIC CONTROL">ECONOMIC EXPLOITATION</option>
                  <option value="EMOTIONAL COERCION">EMOTIONAL EXPLOITATION</option>
                  <option value="STALKING">STALKING / TRACKING DEVICE</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-dark/60">DESCRIPTION (EVIDENCE JOURNAL)</label>
                <textarea 
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="EXPLAIN IN RIGOROUS CHRONICLED DETAIL WHAT OCCURRED..."
                  className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs outline-none resize-none focus:bg-accent focus:text-white transition-colors"
                  required
                />
              </div>

              {/* Drag and Drop Upload Support */}
              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-dark/40">ATTACH DIGITAL PROOFS (SCREENSHOTS, AUDIO)</label>
                <div 
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed border-dark p-6 transition-colors text-center cursor-pointer relative ${
                    dragActive ? 'bg-accent/10 border-accent' : 'bg-page'
                  }`}
                >
                  <input 
                    type="file" 
                    multiple 
                    onChange={handleManualUpload} 
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                  />
                  <UploadCloud className="w-8 h-8 mx-auto text-dark/50 mb-2" />
                  <p className="text-[10px] font-black uppercase tracking-widest">DRAG AND DROP SCREENSHOTS/AUDIO PROOF HERE OR CLICK TO UPLOAD</p>
                </div>

                {attachments.length > 0 && (
                  <div className="bg-dark text-white p-3 font-mono text-[9px] uppercase space-y-1 block max-h-32 overflow-y-auto">
                    <p className="border-b border-white/20 pb-1 mb-1 font-black text-accent">ATTACHED EVIDENCE FILES:</p>
                    {attachments.map((name, i) => (
                      <div key={i} className="flex justify-between items-center bg-white/10 p-1 px-1.5 font-bold">
                        <span>📄 {name}</span>
                        <button type="button" onClick={() => setAttachments(prev => prev.filter((_, idx) => idx !== i))} className="text-red-400 hover:text-red-500 font-bold px-1 ml-2">DELETE</button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-dark/60">CONFIDENTIAL DISCRETION MODE</label>
                <select 
                  value={confidentiality}
                  onChange={(e) => setConfidentiality(e.target.value as any)}
                  className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs outline-none"
                >
                  <option value="Strict Vault Only">STRICT VAULT ONLY (ENCRYPT TO DEVICE ONLY)</option>
                  <option value="Share with Advocates">SHARE WITNESS METRICS TO LEGAL AID SPECIALISTS</option>
                </select>
              </div>

              <button type="submit" className="brutalist-btn-red w-full py-5 text-lg">
                SUBMIT SECURE JOURNAL ENTRY
              </button>
            </form>
          </div>
        </div>

        {/* Right Side: Logged Vault View */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-dark text-white border-4 border-dark p-8 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-6">
            <h3 className="text-2xl font-black text-accent flex items-center gap-2">
              <Lock className="w-6 h-6 shrink-0" />
              SECURED JOURNAL DATA
            </h3>

            {currentUser ? (
              <div className="space-y-4">
                <div className="bg-white/5 border border-white/20 p-4 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] opacity-40 uppercase">AUTHENTICATED USER</p>
                    <p className="text-sm font-black text-white uppercase">{currentUser.username}</p>
                  </div>
                  <span className="text-[9px] font-black bg-accent text-white py-1 px-2 uppercase rounded-full tracking-widest animate-pulse">VAULT LOCKED</span>
                </div>

                <div className="space-y-6 pt-4">
                  <div className="flex justify-between items-center">
                    <p className="text-[10px] font-black opacity-40 uppercase">TIMELINE RECORDINGS ({reports.length})</p>
                    {reports.length > 0 && (
                      <button 
                        onClick={() => {
                          const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(reports, null, 2));
                          const downloadAnchor = document.createElement('a');
                          downloadAnchor.setAttribute("href", dataStr);
                          downloadAnchor.setAttribute("download", `esos_evidence_ledger_${currentUser.id}.json`);
                          document.body.appendChild(downloadAnchor);
                          downloadAnchor.click();
                          downloadAnchor.remove();
                        }}
                        className="text-[9px] font-black text-accent uppercase hover:underline flex items-center gap-1 border-0 outline-none"
                      >
                        <Download className="w-3.5 h-3.5" /> DOWNLOAD LEGAL JSON
                      </button>
                    )}
                  </div>

                  <div className="space-y-4 max-h-[460px] overflow-y-auto pr-2">
                    {reports.length === 0 ? (
                      <p className="text-center text-xs font-bold uppercase opacity-40 py-8">NO INCIDENTS RECORDED YET</p>
                    ) : (
                      reports.map((r) => (
                        <div key={r.id} className="bg-white/5 p-4 border border-white/10 space-y-3 relative group">
                          <button 
                            type="button" 
                            onClick={() => handleDeleteReport(r.id)}
                            className="absolute top-4 right-4 text-gray-500 hover:text-accent transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>

                          <div className="flex gap-2 items-center flex-wrap">
                            <span className="text-[8px] font-black bg-accent text-white px-2 py-0.5 tracking-wider uppercase mb-1">{r.type}</span>
                            <span className="text-[8px] font-semibold opacity-40 block">{r.date} @ {r.time}</span>
                          </div>

                          <h4 className="text-sm font-black text-white uppercase pr-6 leading-tight">{r.title}</h4>
                          <p className="text-[10px] opacity-70 leading-relaxed font-sans">{r.description}</p>
                          
                          {r.attachments && r.attachments.length > 0 && (
                            <div className="pt-2 border-t border-white/10">
                              <p className="text-[8px] opacity-40 font-bold uppercase mb-1">SECURED PROOFS:</p>
                              <div className="flex flex-wrap gap-1">
                                {r.attachments.map((name, idx2) => (
                                  <span key={idx2} className="bg-white/10 text-white text-[8px] px-2 py-0.5 font-sans">📄 {name}</span>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex items-center gap-2 pt-2 border-t border-dashed border-white/10 text-[8px] text-accent font-black tracking-widest uppercase">
                            <span>● STATUS: {r.status}</span>
                            <span className="opacity-30">|</span>
                            <span>ACCESS: {r.confidentiality}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 space-y-6">
                <Lock className="w-12 h-12 text-accent mx-auto animate-bounce" />
                <div className="space-y-2">
                  <p className="text-sm font-black uppercase">VAULT IS LOCKED BY DEFAULT</p>
                  <p className="text-[10px] font-bold uppercase opacity-60 leading-normal max-w-xs mx-auto">
                    TO PREVENT THREATS AND PHYSICAL SNATCHING FROM ABUSERS, INDIVIDUAL REPORT LEDGERS REQUIRE YOU TO CONFIGURE A SESSION ACCOUNT.
                  </p>
                </div>
                <button 
                  onClick={onNavigateToAuth}
                  className="brutalist-btn-red text-xs px-6 py-4 mx-auto block flex items-center gap-2"
                >
                  <LogIn className="w-4 h-4" /> LOG IN OR CREATE ACCOUNT TO ACTIVATE VAULT
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
