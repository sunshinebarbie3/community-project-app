/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, Users, Plus, Trash2, ShieldCheck, HeartPulse, Send, MapPin, Search, AlertOctagon, CornerDownRight } from 'lucide-react';
import { PersonalContact, User } from '../types';

interface EmergencyContactsPageProps {
  currentUser: User | null;
}

const OFFICIAL_HOTLINES = [
  { name: "GBV Command Centre", phone: "0800 428 428", category: "Therapy & Abuse Help", details: "Available toll-free 24/7. Immediate trauma counselor debriefing." },
  { name: "SAPS Nationwide Emergency", phone: "10111", category: "Immediate Police Dispatch", details: "All sectors nationwide South African Police emergency line." },
  { name: "Family Violence Unit (FCS)", phone: "08600 10111", category: "Sex Offence & Child Protection", details: "To open protection filings and investigate active domestic assaults." },
  { name: "Childline South Africa", phone: "0800 055 555", category: "Youth Support System", details: "Toll-free 24-hours assistance in all official languages." },
  { name: "Tears Foundation helpline", phone: "*134*7355#", category: "Self-Help Emergency USSD", details: "USSD interactive responder finding nearest emergency clinic locations." },
  { name: "LifeLine SA National Crisis", phone: "0861 322 322", category: "Assisted Suicide & Trauma Care", details: "Emotional check-up and direct physical health debriefings." },
  { name: "Legal Aid Advice Centre", phone: "0800 110 110", category: "State Pro-bono Defense Lawyers", details: "Assists survivors on filling domestic protective actions legally." }
];

export default function EmergencyContactsPage({ currentUser }: EmergencyContactsPageProps) {
  const [personalContacts, setPersonalContacts] = useState<PersonalContact[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [newName, setNewName] = useState('');
  const [newRelation, setNewRelation] = useState('TRUSTED FRIEND');
  const [newPhone, setNewPhone] = useState('');
  const [alertLogs, setAlertLogs] = useState<string[]>([]);
  const [isAlerting, setIsAlerting] = useState<string | null>(null);

  useEffect(() => {
    const key = currentUser ? `esos_allies_${currentUser.id}` : 'esos_guest_allies';
    const stored = localStorage.getItem(key);
    if (stored) {
      setPersonalContacts(JSON.parse(stored));
    } else {
      const defaultAllies: PersonalContact[] = [
        { id: 'all1', name: 'SISTER THANDI', relationship: 'SIBLING', phone: '072 345 6789' },
        { id: 'all2', name: 'COUSELOR NKOSI', relationship: 'ADVOCATE CASE-WORKER', phone: '083 987 6543' }
      ];
      setPersonalContacts(defaultAllies);
      localStorage.setItem(key, JSON.stringify(defaultAllies));
    }
  }, [currentUser]);

  const handleAddAlly = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newPhone) return;

    const newAlly: PersonalContact = {
      id: `ally-${crypto.randomUUID()}`,
      name: newName.toUpperCase(),
      relationship: newRelation.toUpperCase(),
      phone: newPhone
    };

    const updated = [...personalContacts, newAlly];
    setPersonalContacts(updated);
    
    const key = currentUser ? `esos_allies_${currentUser.id}` : 'esos_guest_allies';
    localStorage.setItem(key, JSON.stringify(updated));

    setNewName('');
    setNewPhone('');
  };

  const handleDeleteAlly = (id: string) => {
    const updated = personalContacts.filter(c => c.id !== id);
    setPersonalContacts(updated);
    const key = currentUser ? `esos_allies_${currentUser.id}` : 'esos_guest_allies';
    localStorage.setItem(key, JSON.stringify(updated));
  };

  const triggerDistressAlert = (ally: PersonalContact) => {
    setIsAlerting(ally.id);
    
    // Web Audio Sound synthesis - alert sound
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
      console.log('AudioContext is blocked or unsupported', e);
    }

    const logMsg = `[ALERT BROADCAST] 🚨 DISPATCHED SILENT DURESS SMS TO ${ally.name} (${ally.phone}) - COORDINATES: "LAT -26.2041, LNG 28.0473" (JOHANNESBURG CENTRAL) - "STRENGTH IN UNITY"`;
    setAlertLogs(prev => [logMsg, ...prev]);

    setTimeout(() => {
      setIsAlerting(null);
    }, 1500);
  };

  const filteredHotlines = OFFICIAL_HOTLINES.filter(hotline => 
    hotline.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    hotline.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="py-24 px-6 max-w-5xl mx-auto space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-7xl font-black text-dark tracking-tighter">
          EMERGENCY <span className="text-accent underline decoration-8">BOOK</span>
        </h1>
        <p className="text-sm font-bold uppercase tracking-widest text-dark/60 max-w-xl mx-auto px-4">
          IMMEDIATE NATIONAL HELPLINES AND PERSONAL GUARDIAN BROADCASTERS. TAP ANY NUMBER TO INSTANTLY TELEPHONE-DIAL.
        </p>
      </div>

      <div className="grid lg:grid-cols-12 gap-12 items-start">
        {/* Left column: Allied Personal Contacts */}
        <div className="lg:col-span-6 space-y-8">
          <div className="bg-white border-4 border-dark p-8 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-6">
            <h2 className="text-2xl font-black border-b-2 border-dark/10 pb-4 flex items-center gap-3">
              <Users className="w-6 h-6 text-accent" />
              PERSONAL ALLIES BOOK
            </h2>

            <p className="text-[10px] font-bold uppercase text-dark/60 leading-normal">
              ADD TRUSTED ADULTS, SIBLINGS, OUTREACH REPRESENTATIVES OR WORKPLACE ALLIES WHO ARE DESIGNATED TO ASSIST YOU. CLICK <span className="text-accent font-black">TRIGGER DISTRESS</span> TO INITIATE CO-ORDINATED SATELLITE WARNINGS TO THEM.
            </p>

            <form onSubmit={handleAddAlly} className="grid sm:grid-cols-12 gap-4 items-end bg-page p-4 border-2 border-dark">
              <div className="sm:col-span-5 space-y-1">
                <label className="text-[9px] font-black uppercase text-dark/50">NAME</label>
                <input 
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="E.G., THANDI K."
                  className="w-full bg-white border border-dark p-2 text-[10px] font-black uppercase outline-none"
                  required
                />
              </div>

              <div className="sm:col-span-3 space-y-1">
                <label className="text-[9px] font-black uppercase text-dark/50">RELATION</label>
                <select 
                  value={newRelation}
                  onChange={(e) => setNewRelation(e.target.value)}
                  className="w-full bg-white border border-dark p-2 text-[10px] font-black uppercase outline-none text-xs"
                >
                  <option value="TRUSTED FRIEND">FRIEND</option>
                  <option value="SIBLING">SIBLING</option>
                  <option value="COUSELOR">COUNSELOR</option>
                  <option value="ADVOCATE">ADVOCATE</option>
                  <option value="NEIGHBOUR">NEIGHBOR</option>
                </select>
              </div>

              <div className="sm:col-span-3 space-y-1">
                <label className="text-[9px] font-black uppercase text-dark/50">PHONE NO.</label>
                <input 
                  type="tel"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  placeholder="082..."
                  className="w-full bg-white border border-dark p-2 text-[10px] font-black outline-none"
                  required
                />
              </div>

              <div className="sm:col-span-1">
                <button type="submit" className="w-full bg-dark text-white p-2 flex items-center justify-center font-black border border-dark hover:bg-accent hover:border-accent height-full">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </form>

            <div className="space-y-4">
              {personalContacts.length === 0 ? (
                <div className="text-center font-black uppercase text-xs opacity-40 p-6 border border-dashed border-dark/20">
                  YOUR ALLY BOOK IS EMPTY. ADD 1 OR MORE CORE PEOPLE ABOVE.
                </div>
              ) : (
                personalContacts.map((contact) => (
                  <div key={contact.id} className="bg-white border-2 border-dark p-4 flex justify-between items-center gap-4 relative">
                    <div>
                      <span className="text-[8px] font-black bg-accent text-white px-2 py-0.5 tracking-wider uppercase">{contact.relationship}</span>
                      <h4 className="text-base font-black uppercase mt-1">{contact.name}</h4>
                      <p className="font-mono text-[10px] opacity-60 font-medium">{contact.phone}</p>
                    </div>

                    <div className="flex gap-2 items-center">
                      <button
                        onClick={() => triggerDistressAlert(contact)}
                        className={`font-black text-[9px] tracking-widest uppercase border-2 border-dark px-3 py-2 flex items-center gap-1.5 transition-all ${
                          isAlerting === contact.id ? 'bg-red-600 text-white animate-pulse' : 'bg-yellow-50 text-dark hover:bg-accent hover:text-white'
                        }`}
                      >
                        <Send className="w-3.5 h-3.5" />
                        {isAlerting === contact.id ? 'ALERT SENT' : 'TRIGGER DISTRESS'}
                      </button>

                      <button 
                        onClick={() => handleDeleteAlly(contact.id)}
                        className="text-dark/40 hover:text-accent p-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Simulated Live Alert Logs */}
            {alertLogs.length > 0 && (
              <div className="bg-dark text-white p-4 font-mono text-[9px] uppercase border-l-4 border-accent space-y-1 max-h-44 overflow-y-auto block">
                <p className="text-accent font-black border-b border-white/20 pb-1 mb-1">LOCAL DISTRESS LOG STREAM:</p>
                {alertLogs.map((log, i) => (
                  <div key={i} className="flex gap-1.5 py-0.5 border-b border-white/5 last:border-0">
                    <MapPin className="w-3.5 h-3.5 text-accent shrink-0" />
                    <span className="leading-normal">{log}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right column: Official Support Hotlines */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white border-4 border-dark p-8 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-6">
            <h2 className="text-2xl font-black border-b-2 border-dark/10 pb-4 flex items-center gap-3">
              <Phone className="w-6 h-6 text-accent" />
              DIRECT SOS HELPLINES
            </h2>

            {/* Hotline Search filter */}
            <div className="relative">
              <input 
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="PROBE EMERGENCY SERVICES BY KEYWORD..."
                className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs pl-12 focus:bg-accent focus:text-white transition-colors outline-none"
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 opacity-40" />
            </div>

            <div className="space-y-4 max-h-[580px] overflow-y-auto pr-2">
              {filteredHotlines.map((hotline, idx) => (
                <div key={idx} className="bg-page border-2 border-dark p-5 group flex justify-between items-center gap-4 hover:bg-white hover:border-accent hover:shadow-[4px_4px_0px_0px_rgba(230,57,70,1)] transition-all">
                  <div className="space-y-1 bg-transparent max-w-sm">
                    <span className="text-[8px] font-black uppercase tracking-wider text-accent">{hotline.category}</span>
                    <h3 className="text-base font-black uppercase">{hotline.name}</h3>
                    <p className="text-[10px] font-medium leading-relaxed uppercase tracking-wider text-dark/70 font-sans">{hotline.details}</p>
                  </div>

                  <a 
                    href={`tel:${hotline.phone}`}
                    className="py-3 px-4 bg-white border-2 border-dark font-black tracking-tighter text-sm uppercase group-hover:bg-accent group-hover:text-white group-hover:border-accent transition-colors shrink-0"
                  >
                    ☏ {hotline.phone}
                  </a>
                </div>
              ))}
            </div>

            <div className="bg-yellow-50 border-2 border-dark p-4 flex gap-3 text-[10px] font-black uppercase leading-normal">
              <AlertOctagon className="w-6 h-6 text-accent shrink-0 animate-pulse" />
              <p>
                SAFETY DIRECTIVE: ALL TELEPHONE LINKS ARE PROTOCOL SHIELDED. DIALING FROM WITHIN THIS INTERACTIVE ENVELOPE WILL NOT HIGHLIGHT ON e.sos REMOTE METRICS LOGS. NEVERTHELESS, IT WILL ENROLL ON YOUR PHONE CARRIER DIAL RECORD. REMEMBER TO MANUALLY EXPUNGE CALL LOGS TO PREVENT TRACKING.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
