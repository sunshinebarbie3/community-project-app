/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Sparkles, MessageSquare, Trash2, Heart, ShieldAlert, X, EyeOff, Scale, HelpCircle } from 'lucide-react';
import { ChatMessage, User } from '../types';

interface SecureChatPageProps {
  currentUser: User | null;
}

const THERAPEUTIC_FLOWS = [
  {
    trigger: "De-escalate Trauma Breathing",
    response: "Let's perform a grounding exercise together to help regulate your nervous system. Remember, you are in a safe space right now.\n\n" +
              "1. Sit comfortably. Touch a physical object (like a table, a ring, or your clothes).\n" +
              "2. Breathe in deeply for 4 seconds.\n" +
              "3. Hold your breath for 4 seconds.\n" +
              "4. Exhale slowly through your mouth for 6 seconds.\n" +
              "5. Repeat this 3 times.\n\n" +
              "When you are ready, type or click any question. I am here for you."
  },
  {
    trigger: "Check Digital Safety Tracker",
    response: "Stalkers often use tracking and devices. Let's run a digital safety audit immediately:\n\n" +
              "• PASSCODES: Change your email and bank passwords from a friend's phone or public library computer instead of your own if you suspect spywares.\n" +
              "• GOOGLE MAPS: Open Google Maps -> tap Profile Icon -> 'Location Sharing'. Review who can see your real-time coordinates.\n" +
              "• APPLE FIND MY/FIND MY DEVICE: Disable shared family access configurations if you've recently departed.\n" +
              "• EXCISE SYNCS: Delete browser histories immediately. We will show you how to clean your device footprint."
  },
  {
    trigger: "Fleeing Plan Essentials",
    response: "If you are planning to leave a hostile domestic location, here is what you need to compile in a hidden, safe place (like a closet corner, friend's laundry, or workplace locker):\n\n" +
              "1. Documents: ID book/card, children's birth certificates, marriage certificates, clinic immunization cards.\n" +
              "2. Finances: Small secret reserves of cash, separate activated visa bank card, copy of bank logs.\n" +
              "3. Medical: Backup prescriptions, chronic medicines, physical clothing changes.\n" +
              "4. Evidence: Print or download your secure e.sos incident logs to hand over directly to court clerks."
  }
];

export default function SecureChatPage({ currentUser }: SecureChatPageProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [decoyMode, setDecoyMode] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial counselor greeting
    const welcomeMsgs: ChatMessage[] = [
      {
        id: 'msg-w1',
        sender: 'system',
        text: 'SECURE CHAT ACTIVATED. END-TO-END META SHIELD IS ACTIVE.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      },
      {
        id: 'msg-w2',
        sender: 'bot',
        text: `Hello ${currentUser ? currentUser.username : 'there'}, I am Nomvula, an automated support specialist from e.sos. I cannot share your data with anyone. You can chat with me about safety plans, legal remedies, or finding nearby shelter. Happy to assist!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];
    setMessages(welcomeMsgs);
  }, [currentUser]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-${crypto.randomUUID()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    // AI responsive mapping simulation
    setTimeout(() => {
      let botText = "I understand this is incredibly difficult. You are extremely strong for documenting this. Let's think about your safety first. Would you like me to help you map local shelters, or review a digital protection order checklist?";
      
      const promptLower = textToSend.toLowerCase();
      if (promptLower.includes('shelter') || promptLower.includes('safehouse') || promptLower.includes('sleep')) {
        botText = "I can definitely guide you on lodging! We partner with several shelters across Johannesburg, Western Cape, and Durban. Please click on the 'FIND SHELTER' directory tab to view safe coordinates and request transport rendezvous.";
      } else if (promptLower.includes('police') || promptLower.includes('court') || promptLower.includes('legal') || promptLower.includes('law')) {
        botText = "To legally protect yourself, we recommend filling a 'Domestic Violence Protection Order' draft. You can complete this at your nearest Magistrates Court. Social workers at e.sos can accompany you. Reach Legal Aid SA on 0800 110 110.";
      } else if (promptLower.includes('hit') || promptLower.includes('hurt') || promptLower.includes('dangerous') || promptLower.includes('panic')) {
        botText = "⚠️ IF YOU ARE IN AN ACTIVE DANGEROUS DISPUTE, PLEASE HIT THE 'PANIC BUTTON' TAB IMMEDIATELY. This initiates active alert count downs and dials national emergency responders. Your physical wellness is the highest priority.";
      } else if (promptLower.includes('fear') || promptLower.includes('cry') || promptLower.includes('afraid')) {
        botText = "Take a slow, deep breath. Your feelings are completely valid. Abuser tracking is psychological war. We can practice a grounding exercise: Click 'De-escalate Trauma Breathing' above to slow down panic ripples.";
      }

      const botMsg: ChatMessage = {
        id: `msg-${crypto.randomUUID()}`,
        sender: 'bot',
        text: botText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 1200);
  };

  const handleSelfDestruct = () => {
    setMessages([
      {
        id: 'msg-sd',
        sender: 'system',
        text: 'CHAT CONVERSATION HISTORY SCRUBBED COMPLETELY FROM TEMPORARY STACKS.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  return (
    <div className="py-24 px-6 max-w-5xl mx-auto space-y-12">
      {/* Decoy Safe Wrapper Layer */}
      {decoyMode ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white border-4 border-dark p-8 md:p-12 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] space-y-8 text-dark"
        >
          <div className="flex justify-between items-center border-b-2 border-dark pb-4">
            <h1 className="text-2xl font-black uppercase text-green-700 font-sans tracking-tight">🥬 HEAL-KITCHEN WEEKLY DIET</h1>
            <button 
              onClick={() => setDecoyMode(false)}
              className="text-xs font-black uppercase border border-dark text-black px-3 py-1 hover:bg-page"
            >
              CLOSE PREVIEW
            </button>
          </div>

          <div className="space-y-6 max-w-2xl font-sans text-xs">
            <h2 className="text-xl font-black">HOW TO CRISP BROCCOLI FOR SOUP CORES</h2>
            <img src="https://picsum.photos/seed/recipe/800/400" alt="Broccoli recipe" className="w-full h-48 object-cover border-2 border-dark" referrerPolicy="no-referrer" />
            <p className="leading-relaxed opacity-80">
              Steaming broccoli retains more nutrients than boiling! Simply wash and trim fresh florets, toss in high-quality olive oil and a pinch of crushed sea salt. Steam for exactly 4 to 5 minutes until tender-crisp. Perfect for a calming weekday meal. Add lemon zest!
            </p>
            <div className="p-4 bg-page border border-dark border-dashed space-y-2">
              <p className="font-bold uppercase">DIETARY TIP OF THE DAY:</p>
              <p className="opacity-70 leading-normal">
                Staying hydrated with mineral water keeps cortisol levels regular. Keep healthy snacks in drawers for prompt meal schedules!
              </p>
            </div>
          </div>
        </motion.div>
      ) : (
        <>
          {/* Real Page Header */}
          <div className="text-center space-y-4">
            <h1 className="text-4xl md:text-7xl font-black text-dark tracking-tighter">
              SECURE <span className="text-accent underline decoration-8">COUNSELOR</span>
            </h1>
            <p className="text-sm font-bold uppercase tracking-widest text-dark/60 max-w-xl mx-auto px-4">
              SILENT IN-CLIENT ADVISORY PORTAL. CHAT IS SECURED LOCALLY FROM BROWSER SNOOPING.
            </p>
          </div>

          <div className="grid lg:grid-cols-12 gap-12 items-stretch">
            {/* Quick Action Guides Column */}
            <div className="lg:col-span-4 space-y-6 flex flex-col justify-between">
              <div className="bg-white border-4 border-dark p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-6">
                <h3 className="text-xl font-black border-b-2 border-dark/10 pb-2">THERAPEUTIC SHORTCUTS</h3>
                <p className="text-[10px] uppercase font-bold text-dark/60 leading-normal">
                  TAP ANY OF THESE PRE-AUTHORIZED RESPONSIVE ACTIONS TO HAVE THE COUNSELOR COMPILE LEGAL OR PHYSICAL RELIEF STRATEGIES IMMEDIATELY.
                </p>

                <div className="flex flex-col gap-3">
                  {THERAPEUTIC_FLOWS.map((flow, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendMessage(flow.trigger)}
                      className="text-left bg-page border-2 border-dark p-3.5 hover:bg-accent hover:text-white transition-all text-[10px] font-black uppercase tracking-wide leading-tight flex items-center gap-2"
                    >
                      <Sparkles className="w-4 h-4 text-accent shrink-0" />
                      {flow.trigger}
                    </button>
                  ))}
                </div>
              </div>

              {/* Security Actions */}
              <div className="bg-dark text-white border-4 border-dark p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] space-y-4">
                <h4 className="text-sm font-black text-accent uppercase flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 shrink-0 animate-pulse" />
                  EMERGENCY INTERCEPTS
                </h4>
                <p className="text-[9px] font-bold uppercase opacity-80 leading-normal">
                  IF SOMEONE IS COMING IN AND YOU NEED TO QUICKLY SCRUB YOUR HISTORY, CLICK "SELF-DESTRUCT" TO BURN CHATS, OR "ACTIVE NEWS DECOY" TO TRANSFORM THIS ENTIRE PAGE INTO AN INNOCENT CHOPPED FOOD WIKI.
                </p>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button 
                    onClick={handleSelfDestruct}
                    className="bg-accent/15 border border-accent text-accent font-black py-2.5 text-[9px] transition-all tracking-wider hover:bg-accent hover:text-white flex items-center justify-center gap-1.5 uppercase"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> SELF-DESTRUCT
                  </button>

                  <button 
                    onClick={() => setDecoyMode(true)}
                    className="bg-white/10 border border-white/20 text-white font-black py-2.5 text-[9px] transition-all tracking-wider hover:bg-white hover:text-dark flex items-center justify-center gap-1.5 uppercase"
                  >
                    <EyeOff className="w-3.5 h-3.5 text-yellow-500" /> NEWS DECOY
                  </button>
                </div>
              </div>
            </div>

            {/* Chat Timeline Terminal */}
            <div className="lg:col-span-8 flex flex-col bg-white border-4 border-dark p-6 shadow-[6px_6px_0px_0px_rgba(26,26,26,1)] min-h-[500px] justify-between">
              
              {/* Header inside chat */}
              <div className="flex justify-between items-center border-b-2 border-dark/10 pb-4 mb-4">
                <div className="flex items-center gap-2 bg-transparent">
                  <MessageSquare className="w-5 h-5 text-accent" />
                  <span className="text-xs font-black uppercase tracking-wider text-dark">COUNSELOR CHAND CONTACT STREAMS</span>
                </div>
                <div className="flex items-center gap-1.5 text-green-700 bg-green-100 border border-green-300 rounded-full px-2.5 py-0.5 text-[8px] font-black uppercase">
                  <span>● SSL PROTECTED</span>
                </div>
              </div>

              {/* Message scroll container */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-2 max-h-[380px] min-h-[300px]">
                {messages.map((msg) => (
                  <div 
                    key={msg.id} 
                    className={`flex flex-col ${
                      msg.sender === 'user' ? 'items-end' : 
                      msg.sender === 'system' ? 'items-center' : 'items-start'
                    }`}
                  >
                    {msg.sender === 'system' ? (
                      <span className="bg-dark text-neutral-400 text-[8px] tracking-widest font-mono p-1.5 px-3 border border-dashed border-neutral-600 block rounded-none uppercase animate-pulse">
                        {msg.text}
                      </span>
                    ) : (
                      <div className="max-w-[85%] space-y-1">
                        <div className="flex items-center gap-2 justify-between">
                          <span className="text-[8px] font-black text-dark/30 uppercase">{msg.sender === 'user' ? 'YOU' : 'NOMVULA'}</span>
                          <span className="text-[8px] font-mono text-dark/30">{msg.timestamp}</span>
                        </div>
                        <div 
                          className={`p-4 border-2 border-dark font-sans text-xs uppercase font-medium leading-relaxed whitespace-pre-wrap ${
                            msg.sender === 'user' ? 'bg-accent text-white' : 'bg-page text-dark'
                          }`}
                        >
                          {msg.text}
                        </div>
                      </div>
                    )}
                  </div>
                ))}

                {isTyping && (
                  <div className="flex flex-col items-start">
                    <span className="text-[8px] font-black text-dark/30 uppercase">NOMVULA</span>
                    <div className="p-3 bg-page border-2 border-dark text-xs font-black uppercase flex items-center gap-1.5">
                      <div className="w-2 h-2 bg-accent rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-accent rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-2 h-2 bg-accent rounded-full animate-bounce [animation-delay:0.4s]" />
                      <span>THINKING DEEP SAFETY CHECK...</span>
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Message Form input */}
              <div className="mt-4 pt-4 border-t-2 border-dashed border-dark/10">
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage(inputText);
                  }}
                  className="flex gap-4 items-stretch"
                >
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="ASK SOMETHING IN CAPITAL LETTERS (E.G. HELP ME PLAN ESCAPING, SECURE HOUSES CAPETOWN)..."
                    className="w-full bg-page border-2 border-dark p-4 font-black uppercase text-xs focus:bg-accent focus:text-white transition-colors outline-none"
                    required
                  />
                  <button 
                    type="submit"
                    className="brutalist-btn-red px-6 text-xs flex items-center justify-center gap-1.5 shrink-0 select-none"
                    id="chat-send-submit"
                  >
                    <Send className="w-4 h-4" /> SEND
                  </button>
                </form>
              </div>

            </div>
          </div>
        </>
      )}
    </div>
  );
}
