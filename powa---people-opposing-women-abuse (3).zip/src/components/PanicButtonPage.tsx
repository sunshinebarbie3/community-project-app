/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, ShieldAlert, Sparkles, Send, MapPin, Phone, RefreshCw, XCircle, Volume2, VolumeX, EyeOff } from 'lucide-react';

export default function PanicButtonPage() {
  const [panicLevel, setPanicLevel] = useState<'idle' | 'countdown' | 'triggered'>('idle');
  const [countdown, setCountdown] = useState(3);
  const [silentMode, setSilentMode] = useState(false);
  const [panicLogs, setPanicLogs] = useState<string[]>([]);
  const [isDecoyOn, setIsDecoyOn] = useState(false);

  // Audio synthesis feedback
  const triggerAudioSiren = (freq1: number, freq2: number, duration: number) => {
    if (silentMode) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq1, audioCtx.currentTime);
      osc.frequency.setValueAtTime(freq2, audioCtx.currentTime + duration / 2);
      
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch (e) {
      console.log('Audio disabled by browser rules', e);
    }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (panicLevel === 'countdown') {
      triggerAudioSiren(440, 880, 0.4);
      setPanicLogs(prev => [`[SECURE METRIC] INITIATED PANIC DEPLOYMENT - CANCEL TIMER STANDBY: ${countdown}s...`, ...prev]);

      interval = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            setPanicLevel('triggered');
            clearInterval(interval);
            return 3;
          }
          triggerAudioSiren(440, 880, 0.4);
          setPanicLogs(p => [`[SECURE METRIC] STANDBY TIMER ENGAGED: ${prev - 1}s...`, ...p]);
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [panicLevel]);

  useEffect(() => {
    if (panicLevel === 'triggered') {
      // Create repetitive logs simulating professional assistance
      const initialLogs = [
        "[DISPATCH ENGINE] SUCCESS: 🚨 EN-ROUTE TRANSIT RESPONDERS SIGNALED ALONG JOHANNESBURG ROUX AXIS.",
        "[SMS BROADCAST] SENT SMS WARNING WITH SATELLITE VECTOR COORDINATES (26.2044° S, 28.0416° E) OUT TO REGISTERED ALLIES.",
        "[COMM ENGINE] CO-ORDINATED WITH SOUTH AFRICAN POLICE FCS DIVISION DIRECT TO DISTRESS PING LOCATION.",
        "[AUDIO ALARM] ALARM BROADCAST GENERATED.",
        "[SECURE LINK] DISSOLVED METADATA IDENTIFIERS TO DISCRETE PACKETS."
      ];
      setPanicLogs(prev => [...initialLogs, ...prev]);

      // Alarm sirens
      const sirenInterval = setInterval(() => {
        triggerAudioSiren(800, 1200, 0.8);
      }, 1000);

      return () => clearInterval(sirenInterval);
    }
  }, [panicLevel]);

  const handleTriggerClick = () => {
    if (panicLevel === 'idle') {
      setCountdown(3);
      setPanicLevel('countdown');
    }
  };

  const handleAbort = () => {
    setPanicLevel('idle');
    setCountdown(3);
    setPanicLogs(p => ["[ABORT TRIGGER] RED ALIGNMENT DE-CONSTRUCTED SUCCESSFULLY. STACKS RESET.", ...p]);
    triggerAudioSiren(220, 110, 0.6);
  };

  return (
    <div className="py-24 px-6 max-w-5xl mx-auto space-y-12">
      {isDecoyOn ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white border-4 border-dark p-8 md:p-12 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] text-dark"
        >
          <div className="flex justify-between items-center border-b-2 border-dark pb-4 mb-6">
            <h1 className="text-xl font-black uppercase text-blue-700 font-mono flex items-center gap-1">⛅ REGIONAL WEATHER FORECAST</h1>
            <button 
              onClick={() => setIsDecoyOn(false)}
              className="text-xs font-black uppercase border border-dark text-black px-3 py-1 hover:bg-page"
            >
              RESTORE PANEL
            </button>
          </div>

          <div className="grid sm:grid-cols-3 gap-6 font-mono text-xs uppercase mb-8">
            <div className="p-4 border-2 border-dark bg-blue-50">
              <p className="font-bold">JOHANNESBURG</p>
              <p className="text-2xl font-black mt-2">19° C</p>
              <p className="opacity-50 mt-1">PARTLY CLOUDY</p>
            </div>
            <div className="p-4 border-2 border-dark">
              <p className="font-bold">CAPE TOWN</p>
              <p className="text-2xl font-black mt-2">14° C</p>
              <p className="opacity-50 mt-1">RAIN SHIELD</p>
            </div>
            <div className="p-4 border-2 border-dark">
              <p className="font-bold">DURBAN</p>
              <p className="text-2xl font-black mt-2">24° C</p>
              <p className="opacity-50 mt-1">HUMID SWELL</p>
            </div>
          </div>

          <p className="text-xs font-sans leading-relaxed opacity-60">
            A weak cold front is moving across the eastern coastal margins, carrying scattered light precipitation. Moderate continental winds from the south-southwest will likely persist overnight, dropping temperatures slightly in the interior highveld sectors.
          </p>
        </motion.div>
      ) : (
        <>
          {/* Header */}
          <div className="text-center space-y-4">
            <h1 className="text-4xl md:text-7xl font-black text-dark tracking-tighter">
              DURESS <span className="text-accent underline decoration-8">PANIC SYSTEM</span>
            </h1>
            <p className="text-sm font-bold uppercase tracking-widest text-dark/60 max-w-xl mx-auto px-4">
              IMMEDIATE ESCORT TRIGGER. LAUNCHES BROADCASTS IN BOTH SILENT AND ADVISORY CONFIGURATIONS.
            </p>
          </div>

          <div className="grid lg:grid-cols-12 gap-12 items-stretch">
            {/* Left: Huge Interactive Trigger Button */}
            <div className="lg:col-span-7 flex flex-col justify-center bg-white border-4 border-dark p-8 md:p-12 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] text-center relative overflow-hidden">
              
              {/* Trigger Indicator */}
              <div className="absolute top-4 left-4 flex gap-2">
                <button
                  type="button"
                  onClick={() => setSilentMode(!silentMode)}
                  className={`border-2 border-dark px-2.5 py-1 text-[8px] font-black uppercase flex items-center gap-1 ${
                    silentMode ? 'bg-[#E63946] text-white' : 'bg-page'
                  }`}
                >
                  {silentMode ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                  {silentMode ? "AUDIO OFF (SILENT SOS)" : "AUDIO ON"}
                </button>

                <button
                  type="button"
                  onClick={() => setIsDecoyOn(true)}
                  className="bg-page hover:bg-dark hover:text-white border-2 border-dark px-2.5 py-1 text-[8px] font-black uppercase flex items-center gap-1"
                >
                  <EyeOff className="w-3.5 h-3.5 text-yellow-500" /> DECOY SHIELD
                </button>
              </div>

              <div className="py-8 flex flex-col items-center justify-center">
                <AnimatePresence mode="wait">
                  {panicLevel === 'idle' && (
                    <motion.div
                      key="idle"
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.9, opacity: 0 }}
                      className="space-y-6 flex flex-col items-center"
                    >
                      <button 
                        onClick={handleTriggerClick}
                        className="w-56 h-56 rounded-full bg-accent hover:bg-dark border-[10px] border-dark text-white text-5xl font-black uppercase tracking-tighter shadow-[0px_12px_0px_0px_rgba(26,26,26,1)] duration-100 hover:translate-y-1 active:translate-y-2 select-none flex items-center justify-center cursor-pointer"
                        id="panic-main-btn"
                      >
                        PANIC
                      </button>
                      <p className="text-xs font-black uppercase text-dark/50 tracking-widest leading-none mt-4">TAP HERE TO TRIGGER EMERGENCY ALARM</p>
                    </motion.div>
                  )}

                  {panicLevel === 'countdown' && (
                    <motion.div
                      key="countdown"
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.9, opacity: 0 }}
                      className="space-y-6 flex flex-col items-center"
                    >
                      <div className="w-56 h-56 rounded-full bg-yellow-500 border-[10px] border-dark text-white text-8xl font-black flex items-center justify-center tracking-tighter animate-pulse select-none">
                        {countdown}
                      </div>

                      <button 
                        onClick={handleAbort}
                        className="bg-dark text-white border-2 border-dark font-black uppercase px-6 py-3 hover:bg-accent hover:border-accent transition-colors text-xs tracking-widest"
                      >
                        ❌ CANCEL (ABORT THREAT ALERT)
                      </button>
                    </motion.div>
                  )}

                  {panicLevel === 'triggered' && (
                    <motion.div
                      key="triggered"
                      initial={{ scale: 1.1, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.9, opacity: 0 }}
                      className="space-y-6 flex flex-col items-center"
                    >
                      <div className="w-56 h-56 rounded-full bg-red-600 border-[10px] border-dark text-white text-3xl font-black flex items-center justify-center tracking-tighter select-none animate-ping">
                        ALARMING
                      </div>

                      <button 
                        onClick={handleAbort}
                        className="bg-dark text-white border-2 border-dark font-black uppercase px-8 py-4 hover:bg-accent transition-colors text-xs tracking-widest relative z-10"
                      >
                        DE-ACTIVATE ALARM SECURELY
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="bg-yellow-100 border-2 border-dark p-4 mt-6 text-[10px] font-black uppercase leading-normal text-amber-900 text-left flex gap-3">
                <AlertCircle className="w-5 h-5 text-accent shrink-0 animate-bounce" />
                <span>
                  INTELLIGENT DURESS BROADCAST STUB: INITIATION IMMEDIATELY LOCKS CURRENT LOCATION VIA GPS, ATTEMPTS NETWORK PING TO SECTOR POLICE CLUSTERS, AND PLACARDS BULLET WARNINGS FOR NEIGHBORS / PRE-SET TRUSTED ALLIES LIST.
                </span>
              </div>

            </div>

            {/* Right: Simulated Real-Time Response Term Logs */}
            <div className="lg:col-span-5 bg-dark text-white border-4 border-dark p-6 shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] flex flex-col justify-between">
              
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-white/10 pb-2">
                  <h3 className="text-sm font-black text-accent tracking-widest flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5 animate-pulse" />
                    LIVE TELEMETRY FEED
                  </h3>
                  <button
                    onClick={() => setPanicLogs([])}
                    className="text-[9px] text-gray-400 hover:text-white uppercase font-bold"
                  >
                    CLEAN
                  </button>
                </div>

                <div className="space-y-2 max-h-[380px] overflow-y-auto font-mono text-[9px] uppercase pr-2">
                  {panicLogs.length === 0 ? (
                    <p className="text-gray-500 italic py-12 text-center text-xs">AWAITING SYSTEM INITIATION SIGNAL...</p>
                  ) : (
                    panicLogs.map((log, idx) => (
                      <div key={idx} className="flex gap-2 border-b border-white/5 pb-2 last:border-0 leading-normal font-medium">
                        <span className="text-accent font-black shrink-0">{`>`}</span>
                        <span>{log}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="border-t border-white/10 pt-4 text-[9px] font-medium opacity-60 flex justify-between uppercase">
                <span>COORD: -26.2044° S, 28.0416° E</span>
                <span>STATE: {panicLevel.toUpperCase()}</span>
              </div>

            </div>
          </div>
        </>
      )}
    </div>
  );
}
