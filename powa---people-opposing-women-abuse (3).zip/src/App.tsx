/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Phone, 
  Shield, 
  Heart, 
  BookOpen, 
  ChevronRight, 
  AlertTriangle, 
  X, 
  Menu,
  Scale,
  HandHeart,
  ExternalLink,
  MessageCircle,
  Clock,
  ArrowRight,
  LogOut,
  User as UserIcon
} from 'lucide-react';
import DonatePage from './components/DonatePage';
import VolunteerPage from './components/VolunteerPage';
import AuthPages from './components/AuthPages';
import FindShelterPage from './components/FindShelterPage';
import ReportIncidentPage from './components/ReportIncidentPage';
import EmergencyContactsPage from './components/EmergencyContactsPage';
import SecureChatPage from './components/SecureChatPage';
import PanicButtonPage from './components/PanicButtonPage';
import { User } from './types';

const RESOURCES = [
  {
    category: "Police & State",
    items: [
      { name: "SAPS Emergency", contact: "10111", desc: "For immediate danger - Nationwide", icon: Shield },
      { name: "Family Violence Unit", contact: "08600 10111", desc: "Sexual Offences & Child Protection", icon: Heart },
    ]
  },
  {
    category: "Support Hotlines",
    items: [
      { name: "GBV Command Centre", contact: "0800 428 428", desc: "Toll-free 24/7 counseling", icon: Phone },
      { name: "Childline SA", contact: "0800 055 555", desc: "Support for minors & families", icon: HandHeart },
    ]
  },
  {
    category: "Legal & Human Rights",
    items: [
      { name: "Legal Aid SA", contact: "0800 110 110", desc: "Legal advice and representation", icon: Scale },
      { name: "Human Rights Comm.", contact: "011 877 3600", desc: "Reporting human rights violations", icon: BookOpen },
    ]
  }
];

const QUICK_LINKS = [
  { name: "About e.sos", href: "#about" },
  { name: "Find Shelter", href: "#find-shelter-page" },
  { name: "Secure Vault", href: "#report-page" },
  { name: "SOS Book", href: "#contacts-page" },
  { name: "Counselor", href: "#chat-page" },
  { name: "Panic System", href: "#panic-page" },
  { name: "Donate", href: "#donate-page" },
  { name: "Volunteer", href: "#volunteer-page" },
];

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'donate' | 'volunteer' | 'auth' | 'find-shelter' | 'report' | 'contacts' | 'chat' | 'panic'>('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    const session = localStorage.getItem('esos_active_session');
    if (session) {
      setCurrentUser(JSON.parse(session));
    }
  }, []);

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('esos_active_session', JSON.stringify(user));
    window.location.hash = '#report-page'; // redirect after login
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('esos_active_session');
    window.location.hash = '';
  };

  const handleDecoyTrigger = () => {
    // Escape to google under abuser duress pressure
    window.location.replace('https://www.google.com');
  };

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash === '#donate-page') {
        setCurrentPage('donate');
        window.scrollTo({ top: 0, behavior: 'instant' });
      } else if (hash === '#volunteer-page') {
        setCurrentPage('volunteer');
        window.scrollTo({ top: 0, behavior: 'instant' });
      } else if (hash === '#auth-page') {
        setCurrentPage('auth');
        window.scrollTo({ top: 0, behavior: 'instant' });
      } else if (hash === '#find-shelter-page') {
        setCurrentPage('find-shelter');
        window.scrollTo({ top: 0, behavior: 'instant' });
      } else if (hash === '#report-page') {
        setCurrentPage('report');
        window.scrollTo({ top: 0, behavior: 'instant' });
      } else if (hash === '#contacts-page') {
        setCurrentPage('contacts');
        window.scrollTo({ top: 0, behavior: 'instant' });
      } else if (hash === '#chat-page') {
        setCurrentPage('chat');
        window.scrollTo({ top: 0, behavior: 'instant' });
      } else if (hash === '#panic-page') {
        setCurrentPage('panic');
        window.scrollTo({ top: 0, behavior: 'instant' });
      } else {
        setCurrentPage('home');
      }
    };
    
    window.addEventListener('hashchange', handleHash);
    handleHash(); // initial check
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const handleQuickEscape = () => {
    // Standard safety feature for domestic abuse websites
    window.location.replace('https://www.google.com');
  };

  return (
    <div className="min-h-screen selection:bg-brand-200 selection:text-brand-900 overflow-x-hidden">
      {/* Brutalist Side Bars */}
      <div className="vertical-bars">
        <div />
        <div />
      </div>
      <div className="vertical-bars-right">
        <div />
        <div />
      </div>

      {/* Navigation */}
      <nav id="navbar" className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-page/95 backdrop-blur-md border-b-2 border-dark py-4' : 'bg-transparent py-8'}`}>
        <div className="max-w-5xl mx-auto px-12 md:px-6 flex justify-between items-center text-center">
          <div className="flex flex-col items-start cursor-pointer" onClick={() => window.location.hash = ''}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-accent flex items-center justify-center border-2 border-dark">
                <span className="text-white font-black text-xl">E</span>
              </div>
              <span className="text-3xl font-black font-display text-dark tracking-tighter uppercase leading-none">e.sos</span>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6 lg:gap-8 animate-fade-in">
            {QUICK_LINKS.map(link => (
              <a 
                key={link.name} 
                href={link.href} 
                className="text-[10px] font-black text-dark hover:text-accent transition-colors uppercase tracking-[0.2em] whitespace-nowrap"
                id={`nav-link-${link.name.toLowerCase().replace(' ', '-')}`}
              >
                {link.name}
              </a>
            ))}
            
            {currentUser ? (
              <div className="flex items-center gap-2 border-l-2 border-dashed border-dark/20 pl-4">
                <span className="text-[9px] font-black text-white bg-accent px-2.5 py-1 uppercase tracking-widest border border-dark">
                  {currentUser.username}
                </span>
                <button
                  onClick={handleLogout}
                  className="p-1.5 text-dark hover:text-accent transition-colors cursor-pointer"
                  title="LOG OUT SECURELY"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <a
                href="#auth-page"
                className="text-[10px] font-black text-dark hover:text-accent uppercase tracking-[0.2em] border-2 border-dark px-3 py-1.5 bg-white select-none whitespace-nowrap"
              >
                LOG IN
              </a>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden p-2 text-dark flex items-center gap-2" onClick={() => setIsMenuOpen(!isMenuOpen)} id="mobile-menu-toggle">
            {currentUser && (
              <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-ping inline-block" />
            )}
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[60] bg-page p-12 md:hidden flex flex-col justify-center text-center overflow-y-auto"
          >
            <button onClick={() => setIsMenuOpen(false)} className="absolute top-8 right-8 p-4 bg-dark text-white"><X className="w-8 h-8" /></button>
            <div className="flex flex-col gap-6 py-12">
              {QUICK_LINKS.map((link, i) => (
                <motion.a 
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 * i }}
                  key={link.name} 
                  href={link.href} 
                  className="text-3xl font-black text-dark hover:text-accent transition-colors uppercase tracking-widest leading-none"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.name}
                </motion.a>
              ))}

              <div className="border-t-4 border-dark pt-6 mt-4 flex flex-col gap-4 items-center">
                {currentUser ? (
                  <>
                    <span className="text-xs font-black text-accent uppercase tracking-widest">
                      LOGGED IN: {currentUser.username}
                    </span>
                    <button
                      onClick={() => {
                        handleLogout();
                        setIsMenuOpen(false);
                      }}
                      className="brutalist-btn-outline w-full py-3.5 text-xs font-black"
                    >
                      LOG OUT SECURELY
                    </button>
                  </>
                ) : (
                  <a
                    href="#auth-page"
                    onClick={() => setIsMenuOpen(false)}
                    className="brutalist-btn-red w-full py-4 text-xs font-black"
                  >
                    SIGN IN / REGISTER VAULT
                  </a>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="max-w-5xl mx-auto bg-page border-x-2 border-dark/5 shadow-2xl relative min-h-screen">
        {currentPage === 'home' && (
          <>
            {/* Hero Section */}
            <section id="hero" className="relative pt-48 pb-24 lg:pt-64 lg:pb-32 overflow-hidden px-12 md:px-24">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
                className="flex flex-col items-center text-center"
              >
                <div className="w-24 h-24 bg-accent flex items-center justify-center mb-10 border-4 border-dark">
                  <span className="text-white font-black text-5xl">E</span>
                </div>
                <h1 className="text-5xl md:text-8xl font-black text-dark leading-none tracking-tighter uppercase mb-12">
                  e.sos
                </h1>
                
                <div className="flex flex-col gap-6 w-full max-w-sm">
                  <button className="brutalist-btn-outline text-xl py-6 bg-accent text-white border-2 border-dark shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] hover:bg-dark hover:translate-x-[2px] hover:translate-y-[2px] transition-all" onClick={() => window.location.hash = '#panic-page'}>
                    PANIC BUTTON
                  </button>
                  <button className="brutalist-btn-outline text-xl py-6 bg-white border-2 border-dark shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] hover:bg-page hover:translate-x-[2px] hover:translate-y-[2px] transition-all" onClick={() => window.location.hash = '#find-shelter-page'}>
                    FIND SHELTER
                  </button>
                </div>

                <div className="mt-24 border-t-4 border-dark pt-12 w-full text-left">
                  <p className="text-2xl font-black text-dark leading-none uppercase tracking-tighter mb-8 italic">
                    Protecting women's rights since 1979.
                  </p>
                  <p className="text-sm font-bold uppercase tracking-widest leading-relaxed opacity-60">
                    e.sos is a feminist organisation initiative that provides professional services, handles GBV cases and advocates for women’s rights. You are not alone.
                  </p>
                </div>
              </motion.div>
            </section>

            {/* About Section */}
            <section id="about" className="py-32 px-12 md:px-24 border-t-4 border-dark bg-white">
              <div className="flex flex-col items-center text-center">
                <h2 className="text-4xl md:text-6xl font-black mb-12 tracking-tighter">OUR MISSION</h2>
                <div className="grid gap-12 w-full">
                  <div className="p-12 border-4 border-dark bg-page">
                    <p className="text-2xl font-black uppercase tracking-tighter leading-none mb-6">A society free from GBV</p>
                    <p className="text-sm font-bold uppercase tracking-widest opacity-60">Where women enjoy their rights and live in dignity.</p>
                  </div>
                  <div className="p-12 border-4 border-dark bg-dark text-white">
                    <p className="text-2xl font-black uppercase tracking-tighter leading-none mb-6 text-accent">High-Quality Service</p>
                    <p className="text-sm font-bold uppercase tracking-widest opacity-60">To survivors of GBV and direct advocacy for law reform.</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Resources Grid */}
            <section id="help" className="py-32 px-12 md:px-24 border-t-4 border-dark bg-page">
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
              >
                <h2 className="text-4xl md:text-6xl font-black text-dark mb-16 tracking-tighter uppercase text-center">
                  EMERGENCY <span className="text-accent underline decoration-8">CONTACTS</span>
                </h2>

                <div className="grid gap-8">
                  {RESOURCES.map((group, idx) => (
                    <div key={idx} className="space-y-8">
                      <h3 className="text-xs font-black text-dark/40 uppercase tracking-[0.4em] text-center">{group.category}</h3>
                      <div className="grid gap-6">
                        {group.items.map((item, i) => (
                          <div key={i} className="bg-white border-4 border-dark p-8 flex flex-col sm:flex-row justify-between items-center gap-6">
                            <div className="text-center sm:text-left">
                              <h4 className="text-xl font-black uppercase mb-1">{item.name}</h4>
                              <p className="text-[10px] font-black uppercase tracking-widest opacity-40">{item.desc}</p>
                            </div>
                            <a href={`tel:${item.contact}`} className="text-3xl md:text-5xl font-black text-accent tracking-tighter border-b-4 border-dark hover:text-dark transition-colors">
                              {item.contact}
                            </a>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </section>

            {/* Resources Grid */}
            <section id="resources" className="py-32 px-12 md:px-24 border-t-4 border-dark bg-white">
              <div className="flex flex-col items-center">
                <h2 className="text-4xl md:text-8xl font-black mb-16 tracking-tighter text-center">RESOURCES</h2>
                <div className="grid md:grid-cols-2 gap-12 w-full">
                  {['Know Your Rights', 'Signs of Abuse', 'Legal Aid', 'Safe Shelters'].map((text, i) => (
                    <div key={i} className="aspect-video relative overflow-hidden group border-4 border-dark">
                      <img src={`https://picsum.photos/seed/edu${i}/800/600`} alt={text} className="w-full h-full object-cover grayscale transition-all duration-700 group-hover:grayscale-0 group-hover:scale-110" referrerPolicy="no-referrer" />
                      <div className="absolute inset-0 bg-accent/40 mix-blend-multiply opacity-0 group-hover:opacity-100 transition-opacity" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <p className="bg-dark text-white px-8 py-4 font-black text-2xl uppercase tracking-tighter border-2 border-accent">{text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* Incident Reporting Section */}
            <section id="report" className="py-32 px-12 md:px-24 border-t-4 border-dark bg-white">
              <div className="max-w-4xl mx-auto">
                <h2 className="text-4xl md:text-6xl font-black text-dark mb-12 tracking-tighter uppercase text-center">
                  SECURE <span className="text-accent underline decoration-8">REPORTING</span>
                </h2>
                <div className="bg-page p-12 border-4 border-dark">
                  <form className="space-y-8" onSubmit={(e) => e.preventDefault()}>
                    <div className="grid md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-dark/40">NAME (OPTIONAL)</label>
                        <input type="text" className="w-full bg-white border-2 border-dark p-4 font-black uppercase outline-none focus:bg-accent focus:text-white transition-colors" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-dark/40">TYPE OF INCIDENT</label>
                        <select className="w-full bg-white border-2 border-dark p-4 font-black uppercase outline-none">
                          <option>PHYSICAL ABUSE</option>
                          <option>PSYCHOLOGICAL</option>
                          <option>ECONOMIC CONTROL</option>
                          <option>LEGAL ASSISTANCE</option>
                        </select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase tracking-widest text-dark/40">INCIDENT DETAILS</label>
                      <textarea rows={4} className="w-full bg-white border-2 border-dark p-4 font-black uppercase outline-none resize-none" />
                    </div>
                    <button className="brutalist-btn-red w-full py-6 text-xl">SUBMIT SECURE REPORT</button>
                  </form>
                </div>
              </div>
            </section>

            {/* SOS Protocol Info */}
            <section className="py-32 px-12 md:px-24 border-t-4 border-dark bg-dark text-white">
              <div className="grid md:grid-cols-2 gap-16">
                <div className="space-y-8">
                  <div className="w-20 h-20 bg-accent flex items-center justify-center border-2 border-white">
                    <AlertTriangle className="w-10 h-10" />
                  </div>
                  <h4 className="text-4xl font-black tracking-tighter uppercase">ONE-TAP SOS</h4>
                  <p className="text-lg font-bold uppercase tracking-tight opacity-70 leading-snug">
                    Immediate GPS capture and dispatcher notification within 3 seconds of activation.
                  </p>
                </div>
                <div className="space-y-8">
                  <div className="w-20 h-20 bg-white text-dark flex items-center justify-center border-2 border-accent">
                    <Shield className="w-10 h-10" />
                  </div>
                  <h4 className="text-4xl font-black tracking-tighter uppercase text-accent">SILENT ALERT</h4>
                  <p className="text-lg font-bold uppercase tracking-tight opacity-70 leading-snug">
                    Discrete activation with zero audio or visual confirmation on the device.
                  </p>
                </div>
              </div>
            </section>

            {/* App Download Section */}
            <section id="app-section" className="py-32 px-12 md:px-24 border-t-4 border-dark bg-page">
              <div className="flex flex-col items-center text-center">
                <h2 className="text-5xl md:text-8xl font-black mb-12 tracking-tighter">GET OUR APP</h2>
                <div className="w-full max-w-sm aspect-[9/19] bg-dark border-[12px] border-dark shadow-2xl relative mb-16">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-dark rounded-b-2xl z-20" />
                  <div className="absolute inset-0 bg-page p-10 flex flex-col items-center justify-center">
                    <div className="w-20 h-20 bg-accent flex items-center justify-center border-4 border-dark mb-10">
                      <span className="text-white font-black text-4xl">E</span>
                    </div>
                    <div className="space-y-4 w-full">
                      <button className="brutalist-btn-red w-full py-4 text-xs">PANIC BUTTON</button>
                      <button className="brutalist-btn-outline w-full py-4 text-xs bg-white">FIND SHELTER</button>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-8">
                  <button className="brutalist-btn-red flex items-center gap-4 px-12">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Download_on_the_App_Store_Badge.svg" alt="App Store" className="h-6" referrerPolicy="no-referrer" />
                  </button>
                  <button className="brutalist-btn-red flex items-center gap-4 px-12">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" alt="Google Play" className="h-6" referrerPolicy="no-referrer" />
                  </button>
                </div>
              </div>
            </section>

            {/* Support CTA */}
            <section id="donate" className="py-40 px-12 md:px-24 border-t-4 border-dark bg-accent text-white">
              <div className="flex flex-col items-center text-center">
                <h2 className="text-7xl md:text-[10rem] font-black leading-[0.8] tracking-tighter uppercase mb-16">
                  REBUILD<br/>LIVES.
                </h2>
                <div className="flex flex-col sm:flex-row gap-8 w-full max-w-2xl">
                  <a href="#donate-page" className="bg-white text-dark w-full py-8 text-3xl font-black uppercase tracking-widest border-4 border-dark hover:bg-dark hover:text-white transition-all flex items-center justify-center">
                    DONATE
                  </a>
                  <a href="#volunteer-page" className="bg-transparent text-white w-full py-8 text-3xl font-black uppercase tracking-widest border-4 border-white hover:bg-white hover:text-dark transition-all flex items-center justify-center">
                    VOLUNTEER
                  </a>
                </div>
              </div>
            </section>
          </>
        )}

        {currentPage === 'donate' && <DonatePage />}
        {currentPage === 'volunteer' && <VolunteerPage />}
        {currentPage === 'auth' && <AuthPages onAuthSuccess={handleLoginSuccess} onDecoyEscape={handleDecoyTrigger} />}
        {currentPage === 'find-shelter' && <FindShelterPage />}
        {currentPage === 'report' && <ReportIncidentPage currentUser={currentUser} onNavigateToAuth={() => window.location.hash = '#auth-page'} />}
        {currentPage === 'contacts' && <EmergencyContactsPage currentUser={currentUser} />}
        {currentPage === 'chat' && <SecureChatPage currentUser={currentUser} />}
        {currentPage === 'panic' && <PanicButtonPage />}

        {/* Footer */}
        <footer id="footer" className="bg-page border-t-4 border-dark pt-32 pb-16 px-12 md:px-24">
          <div className="grid md:grid-cols-12 gap-16 mb-24 items-start">
            <div className="md:col-span-6">
              <div className="flex items-center gap-3 mb-12">
                <div className="w-12 h-12 bg-accent flex items-center justify-center border-2 border-dark">
                  <span className="text-white font-black text-3xl">E</span>
                </div>
                <span className="text-4xl font-black text-dark tracking-tighter uppercase">e.sos</span>
              </div>
              <p className="text-2xl font-black text-dark uppercase tracking-tight leading-none mb-10 italic">
                Protecting women's rights since 1979.
              </p>
            </div>
            
            <div className="md:col-span-3">
              <h4 className="text-[10px] font-black text-dark/40 uppercase tracking-[0.4em] mb-10">NAVIGATION</h4>
              <ul className="space-y-6">
                {QUICK_LINKS.map(link => (
                  <li key={link.name}>
                    <a href={link.href} className="text-sm font-black text-dark hover:text-accent transition-all uppercase tracking-widest flex items-center gap-2 group">
                      {link.name}
                      <ArrowRight className="w-4 h-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="md:col-span-3">
              <h4 className="text-[10px] font-black text-dark/40 uppercase tracking-[0.4em] mb-10">CONTACT</h4>
              <div className="space-y-4">
                <p className="text-xl font-black text-dark">011 642 4345</p>
                <p className="text-sm font-bold uppercase tracking-widest opacity-60">JOHANNESBURG, SA</p>
              </div>
            </div>
          </div>
          
          <div className="pt-12 border-t-2 border-dark flex flex-col md:flex-row justify-between items-center gap-8">
            <p className="text-[10px] font-black text-dark/40 uppercase tracking-[0.2em]">
              © 2026 e.sos. NPO 001-314. STRENGTH IN UNITY.
            </p>
          </div>
        </footer>
      </main>
    </div>
  );
}
